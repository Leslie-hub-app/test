# DOMINIUM V8 — Living Corporate Boardroom

## Purpose
The corporate boardroom is now a playable governance system for companies in which the player is an owner/shareholder, director, chairperson or controlling owner.

## Player access
- Shareholder: can observe corporate governance but does not receive a board vote unless a board seat is represented.
- Director: can convene and vote on board proposals.
- Chairperson: controlling ownership (51%+) gives board leadership and voting authority.
- Owner: 100% ownership gives full board authority.

## Meeting agendas
- Strategy
- Capital allocation
- CEO performance
- Executive compensation
- Dividends
- Debt
- Capital expenditure
- M&A mandate
- Restructuring
- Risk / crisis response

## Voting
Board votes are weighted by represented ownership. Non-player directors use their board agenda, support level and the proposal text to determine their probability of supporting, opposing or abstaining. The result is not deterministic, so board relationships and circumstances matter.

## Consequences
Approved or rejected proposals alter the company state. Examples include:
- productivity, morale and brand changes;
- cash and debt movements;
- dividend payout policy;
- asset/capacity changes;
- market share and valuation expectations;
- CEO approval;
- credit quality;
- workforce size and labor pressure.

Every meeting creates persistent minutes and a business event in the canonical event feed. Recent minutes remain visible in the company boardroom.

## Living-world connection
Board decisions affect the same Company objects consumed by the corporate management, workforce, banking/credit, capital-markets and monthly simulation engines. This allows a board decision to propagate into employees, company finances, credit, markets and future events rather than ending at the boardroom screen.
