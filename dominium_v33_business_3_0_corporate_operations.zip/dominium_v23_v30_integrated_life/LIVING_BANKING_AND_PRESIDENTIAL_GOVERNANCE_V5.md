# Dominium Living Banking & Presidential Governance v5

## Banking
- Multiple accounts at multiple institutions.
- Product types: checking, savings, high-yield savings, money market, fixed deposits/CDs, retirement, offshore and business accounts.
- Institution-specific deposit bonuses, fees, minimums, stability and reputation.
- Central-bank/benchmark rate transmission into variable deposit yields.
- Fixed-term lockups and maturity behavior.
- Persistent bank relationship scores.
- Living bank officers and future underwriting relationship hooks.
- Monthly banking narratives written into the canonical events feed.
- Bank narratives are generated from rate, service, credit and risk conditions and processed during the monthly simulation loop.

## Political governance
- Campaigns for local and national public offices.
- Eligibility based on reputation and world influence.
- Campaign budget and polling state.
- Campaign outcome after a multi-month electoral cycle.
- Office-specific powers and jurisdiction boundaries.
- Public administration actions for budgets, infrastructure, health, education, public safety, economy, environment, housing, transport and foreign affairs.
- National actions directly modify the current country's living-world indicators.
- Approval and policy histories persist.
- Political narratives are written into the canonical events feed.
- Existing political campaign/event-chain systems remain the broader narrative layer; this engine provides persistent administrative state and simulation inputs.

## Presidential end state
When the player reaches President / Prime Minister, the same management interface exposes the broadest authority set. Country-level decisions can influence infrastructure, health, education, political stability and GDP growth, while the existing government engine continues to handle treasury, sovereign debt, cabinet, strategic assets and international crises.
