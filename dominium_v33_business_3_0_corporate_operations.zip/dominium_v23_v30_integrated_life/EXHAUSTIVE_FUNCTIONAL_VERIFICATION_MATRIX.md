# Dominium Repository Functional Verification Matrix

Generated static audit. Runtime verification remains authoritative.

| File | Controls | onClick | Placeholder markers | Initial status |
|---|---:|---:|---:|---|
| src/components/BottomNav.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/DecisionHistoryView.tsx | 5 | 5 | 2 | REPAIR_REQUIRED |
| src/components/DelayedConsequencesTracker.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/DynastySuccessionModal.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/ErrorBoundary.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/EventChainTracker.tsx | 4 | 5 | 0 | CONNECTED_CANDIDATE |
| src/components/EventControlMonitor.tsx | 3 | 3 | 0 | CONNECTED_CANDIDATE |
| src/components/Header.tsx | 5 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/IntegrationTestModal.tsx | 6 | 7 | 0 | CONNECTED_CANDIDATE |
| src/components/LegacyReportModal.tsx | 4 | 4 | 0 | CONNECTED_CANDIDATE |
| src/components/LifeEventFeed.tsx | 9 | 10 | 0 | CONNECTED_CANDIDATE |
| src/components/LifeProgressionModal.tsx | 6 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/MonthAdvanceModal.tsx | 9 | 9 | 0 | CONNECTED_CANDIDATE |
| src/components/ObjectivesHub.tsx | 12 | 12 | 2 | REPAIR_REQUIRED |
| src/components/PlayerPowerProfileModal.tsx | 6 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/StatusDetailModal.tsx | 3 | 3 | 0 | CONNECTED_CANDIDATE |
| src/components/WelcomeScreen.tsx | 4 | 4 | 0 | CONNECTED_CANDIDATE |
| src/components/composition/AttentionCenter.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/composition/EmptyState.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/composition/EntityCard.tsx | 1 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/composition/InsightCard.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/composition/MetricStrip.tsx | 0 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/composition/MobileActionSheet.tsx | 1 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/composition/QuickActionBar.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/dynasty/DynastyProfileSection.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/dynasty/DynastyTimelineView.tsx | 1 | 1 | 1 | REPAIR_REQUIRED |
| src/components/dynasty/SuccessionPlanningStudio.tsx | 9 | 9 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/ExpandedBankingSection.tsx | 12 | 13 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/ExpandedCareerSection.tsx | 8 | 8 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/ExpandedCorporateSection.tsx | 6 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/ExpandedGovernmentSection.tsx | 7 | 7 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/ExpandedInvestmentSection.tsx | 9 | 10 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/ExpandedLegalSection.tsx | 6 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/ExpandedPropertySection.tsx | 6 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/expansion2/FinancialLedgerModal.tsx | 3 | 3 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/BusinessEmpireHub.tsx | 11 | 10 | 1 | REPAIR_REQUIRED |
| src/components/hubs/DecisionInbox.tsx | 19 | 20 | 1 | REPAIR_REQUIRED |
| src/components/hubs/EconomyHub.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/EmpireHub.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/FamilyHub.tsx | 20 | 20 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/LifeAndDynastyHub.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/LifeHub.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/MoreHub.tsx | 4 | 4 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/NewsHub.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/PoliticsHub.tsx | 9 | 9 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/ProjectsHub.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/SettingsHub.tsx | 15 | 13 | 2 | REPAIR_REQUIRED |
| src/components/hubs/SportsHub.tsx | 3 | 3 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/WealthHub.tsx | 2 | 2 | 0 | CONNECTED_CANDIDATE |
| src/components/hubs/WorldHub.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/layout/FloatingStatusBar.tsx | 12 | 12 | 0 | CONNECTED_CANDIDATE |
| src/components/layout/ResponsiveGameLayout.tsx | 6 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/life/LifeCareerWorkplaceView.tsx | 12 | 12 | 0 | CONNECTED_CANDIDATE |
| src/components/life/LifeDatingHubView.tsx | 6 | 7 | 2 | REPAIR_REQUIRED |
| src/components/life/LifeEducationUniversitiesView.tsx | 3 | 3 | 0 | CONNECTED_CANDIDATE |
| src/components/life/LifeMarketplaceView.tsx | 5 | 5 | 2 | REPAIR_REQUIRED |
| src/components/life/LifeMeProfileView.tsx | 3 | 3 | 0 | CONNECTED_CANDIDATE |
| src/components/life/LifeOverviewView.tsx | 19 | 19 | 0 | CONNECTED_CANDIDATE |
| src/components/life/LifeRelationshipsView.tsx | 5 | 5 | 0 | CONNECTED_CANDIDATE |
| src/components/life/LifeScheduleView.tsx | 4 | 4 | 0 | CONNECTED_CANDIDATE |
| src/components/life/LifeSocialMediaView.tsx | 2 | 4 | 2 | REPAIR_REQUIRED |
| src/components/life/LifeWellnessView.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/modals/InstallMobileModal.tsx | 3 | 4 | 0 | CONNECTED_CANDIDATE |
| src/components/navigation/GlobalSecondaryNav.tsx | 3 | 3 | 0 | CONNECTED_CANDIDATE |
| src/components/world/AutonomousNpcHub.tsx | 7 | 7 | 1 | REPAIR_REQUIRED |
| src/components/world/LivingCompetitorsHub.tsx | 6 | 6 | 0 | CONNECTED_CANDIDATE |
| src/components/world/LivingHistoryHub.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/world/LivingWorldOverview.tsx | 1 | 1 | 0 | CONNECTED_CANDIDATE |
| src/components/world/NpcProfileModal.tsx | 9 | 9 | 0 | CONNECTED_CANDIDATE |
| src/engine/masterFunctionalityAudit.ts | 0 | 0 | 2 | REPAIR_REQUIRED |

## Required lifecycle matrix
Every screen/control must be verified through `EXISTS → UI CONNECTED → STATE → SIMULATION → EVENTS/HISTORY → PERSISTENT → TESTED → WORKING`. Static discovery cannot prove runtime behavior; all non-trivial controls remain subject to integration verification.
