# DOMINIUM Business 3.0 — Corporate Operations & Markets

Business 3.0 extends the canonical Business 2.0 operational state with a corporate market layer. It does not create a second company entity. Each company receives a `businessCorporateMarket` record keyed by the existing company id.

## Implemented systems
- Procurement negotiation and purchase orders
- Supplier contracts
- Sales representatives, quotas, attainment and training
- Customer churn/retention
- Pricing decisions connected to existing products
- HR retention signals
- Treasury and working-capital metrics
- Receivables/payables and liquidity coverage
- Corporate insurance policies and premiums
- Corporate tax accrual/payment scheduling
- Regulatory/compliance scoring
- Competitor strategy signals
- Distress, restructuring and turnaround status
- Executive/owner management remains inherited from Business 2.0

## Simulation flow

Market demand -> sales -> revenue -> receivables -> treasury -> procurement/payables -> operating margin -> taxes/insurance -> liquidity -> distress/restructuring.

Competitor threat and service quality influence customer retention. Sales skill influences attainment. Persistent liquidity pressure can move a company from NORMAL to WATCH to RESTRUCTURING. Material distress is published to the World Governor.

## Integration

`simulationEngine.ts` executes Business 2.0 operations and then Business 3.0 corporate-market processing in the same monthly simulation tick. World Governor actions are emitted for procurement negotiations, sales training, pricing decisions and material restructuring risk.
