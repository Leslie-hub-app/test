# DOMINIUM V14 — Current App Fix & UX/Runtime Pass

Implemented against the uploaded DOMINIUM source.

## Changes
- Home chronology events are collapsed by default; only title + one-line summary is visible until Details is opened.
- Vitals & Status HUD is now a persistent fixed floating control. It can be dragged around the viewport, expanded/collapsed, and remains outside normal page flow across game screens. Position is persisted locally.
- Life Overview pressure mitigations are limited to once per item per month and the limit persists in GameState.
- Life Overview responsibilities have a monthly maintenance action, once per responsibility per month.
- State-driven opportunities are limited to one accepted opportunity per month.
- Career-catalog Apply buttons now create/use a real living-world corporate vacancy and enter the same 3-question corporate interview/hiring pipeline rather than directly assigning a job.
- If a suitable public company does not exist for a career field, the corporate career pipeline creates a fictional employer and records the vacancy in the corporate system.
- The app now deliberately opens on the landing page after a browser/app restart. Continue Last Game explicitly loads the autosave; manual slots remain available.
- Device autosave remains local to the player's browser/device and is debounced to avoid repeated JSON serialization during active UI changes.
- Month simulation was moved off the browser UI thread into a Vite module Web Worker. The simulation button now waits asynchronously for the worker instead of blocking React/browser rendering.

## Runtime safety
The worker does not create a player-facing long-horizon simulation control. Existing World Governor / simulation governance remains responsible for long-horizon world processing.

## Verification
`npx tsc --noEmit` was run against the source. The output contains the repository's missing-dependency errors because `node_modules` is not included in the uploaded project. No additional semantic error was reported for the modified files beyond missing React/Lucide module resolution.
