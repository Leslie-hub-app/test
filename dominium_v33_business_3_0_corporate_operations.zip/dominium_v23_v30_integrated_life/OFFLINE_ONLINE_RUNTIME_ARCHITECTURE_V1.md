# DOMINIUM Offline/Online Runtime Architecture V1

DOMINIUM is now designed as an **offline-first simulation with optional online services**.

## Principles
- The local World Governor and simulation engines are authoritative for single-player offline play.
- Local persistence is always available; online services are optional.
- Losing connectivity must never stop, reset, or invalidate a running world.
- Online synchronization is an adapter boundary, not a dependency of the simulation engines.
- Multiplayer, cloud saves, online social and online economy can be added without rewriting the offline simulation.

## Runtime states
`OFFLINE` → `ONLINE` → `ONLINE_SYNCING` → `ONLINE` and `ONLINE` → `ONLINE_DISCONNECTED` → `OFFLINE`.

## Persistence
The game keeps the existing synchronous save-slot system and mirrors the active world to IndexedDB when available. localStorage remains a fallback. This gives browser/device persistence without making the simulation wait for asynchronous storage.

## World Governor
The Governor owns:
- engine registry and dependency graph
- dependency-safe execution plan
- adaptive simulation detail
- player-interest prioritization
- causal message bus
- event/decision compression
- reconciliation and anomaly recovery
- checkpoints
- long-horizon simulation scheduling

Domain engines continue to own their rules. The Governor coordinates them instead of duplicating them.

## Long-horizon simulation
The Web Worker executes the existing monthly simulation off the UI thread and yields periodically. The Governor exposes a capped internal horizon of 100,000 months and chooses a batch/yield policy based on adaptive LOD. There is no player-facing long-horizon button.

## Online adapter boundary
`LocalFirstRuntime` accepts an optional `OnlineSyncAdapter`. If no adapter exists, the game remains fully functional offline. If a future cloud/multiplayer service fails, the local world continues and the failure is recorded as a runtime status rather than blocking play.
