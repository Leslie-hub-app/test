# DOMINIUM Politics 4.0 — Unified Political Simulation

## Objective
Politics 4.0 merges the existing political career, parties, campaign chains, Political Governance profile, Government Living parliament/cabinet/budget structures, Constitutional Offices and Politics 3.0 state into one causal political layer. It does not replace those systems or create a parallel political game.

## Unified data flow
- `state.politics` remains the legacy/public API and owns the player's current office, parties, national policy choices and past offices.
- `state.politicalGovernance` remains the existing public-office/campaign/policy layer.
- `state.governmentLiving` remains the existing government machinery, parliament, ministries, budgets, procurement, elections and diplomacy layer.
- `state.politics.advanced` remains the Politics 3.0 influence/faction/campaign/scandal layer.
- `state.politics.politics4` is the coordination layer that enriches and synchronizes those structures.

## Politics 4.0 simulation
### Politicians
Every major politician has:
- party and faction
- constituency
- ideology
- ambition
- influence
- loyalty
- donor dependence
- scandal exposure
- reputation
- attendance
- competence
- incumbency
- constituency interests
- persistent voting record

### Voter blocs
The engine models six weighted blocs:
- Working Households
- Professionals & Middle Income
- Business & Investors
- Young Voters
- Retirees & Pensioners
- Civic & Community Organizations

Each bloc has issue weights, party affinity, turnout, trust and economic sensitivity.

### Legislature
Bills move through:
`COMMITTEE -> DEBATE -> VOTING -> PASSED/FAILED`

Each bill gets an economic forecast covering:
- GDP
- employment
- inflation
- fiscal impact
- corporate conditions
- banking conditions
- real estate
- household impact
- approval
- forecast confidence

Individual legislators vote using ideology, constituency pressure, loyalty, donor dependence, scandal exposure and player relationship.

### Government formation
Politics 4.0 can form majority/minority governments, maintain coalition agreements and run confidence votes. Low stability can collapse a government and generate a living-world political event/news item.

### Elections
Elections use weighted individual voter blocs and candidate characteristics instead of a single global popularity number. Candidates are evaluated on party affinity, competence, reputation, incumbency and scandal exposure. Results create a certified election record and a new government.

### Living-world propagation
Enacted policies propagate to:
- country GDP growth
- unemployment
- inflation
- market confidence
- business confidence
- company valuation and profitability
- banking relationship conditions
- real-estate confidence
- government legislative records
- World Governor player-action journal

This is deliberately a feedback loop, not a one-way UI update.

## World Governor integration
Politics remains a single high-priority Governor engine. Politics 4.0 publishes player actions through `recordWorldPlayerAction` and participates in the existing dependency graph.

## Offline operation
Politics 4.0 is pure local simulation state and does not require internet access. It therefore works with the project's offline-first runtime and can later synchronize through the optional online adapter.
