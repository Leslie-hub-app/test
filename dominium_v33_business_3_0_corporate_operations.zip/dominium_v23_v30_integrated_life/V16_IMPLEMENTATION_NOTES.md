# DOMINIUM V16 — Integrated Wealth, Corporate & World Hub Upgrade

## Implemented

1. **Market Exchange Order Terminal**
   - The stock order terminal is now a modal opened when a player selects a stock.
   - It no longer renders below the stock list.
   - Close control added.

2. **Unified Banking & Credit**
   - Wealth navigation merges the former Banking & Credit Engine and Banks & Accounts destination into one Banking & Accounts module.
   - Existing banking and credit engines remain authoritative; no duplicate banking system was created.
   - Added a revolving-credit facility using the existing credit profile: limit, balance, utilization, draw and repayment.
   - Credit utilization now feeds credit-score assessment.
   - Living banking/corporate counterparties are nested in the same banking module.

3. **Living Transaction Ledger**
   - Financial transactions now also publish compact player-action records to the World Governor journal.
   - This keeps the ledger connected to wealth, banking and macro-economic governance.

4. **Universal Foldable Sections**
   - Added a reusable FoldableSection component.
   - Foldable sections listen for `dominium-hub-change` and automatically close when the primary hub changes.
   - Wealth, Empire, World, Politics, banking, sports, conditional-consequence and delayed-consequence areas use the foldable pattern.

5. **Living Wealth Network**
   - Banking network, investment platforms/NPC research and wealth-network intelligence are separately foldable.

6. **Corporate Exchange / Companies consolidation**
   - Corporate Exchange is no longer a standalone Empire destination.
   - It is accessible from the selected company under Companies.
   - IPO, M&A, debt, equity, AGM, activism, lobbying, procurement and antitrust functions are grouped under the selected company's capital-market area.
   - Added Corporate Governance Intelligence for board confidence, CEO confidence, succession readiness, regulatory risk, corporate cycle and institutional exposure.

7. **Corporate market limitations**
   - IPO requires minimum $10M pre-listing enterprise value.
   - IPO float is limited to 35% of existing shares.
   - A company cannot repeat an IPO inside the 24-month seasoning window.
   - Secondary offerings are limited to 20% of existing shares.

8. **Dynamic global wealth ranking**
   - Ranking now incorporates the player, player-owned corporate equity, living NPC wealth where available, and fictional major wealth holders.
   - The ranking is capped to the top 20 for UI performance.

9. **Living-world governance feedback**
   - World Governor registry now includes education, social, justice, tax, sports, wealth and corporate-governance engines.
   - Added cross-engine feedback signals for education → employment/corporates, social → politics, justice → corporate access, and corporate governance → capital markets.
   - Governor also updates political polling from macroeconomic conditions and aligns corporate deep-simulation macro variables with the canonical living economy.

10. **Justice / public institutions**
    - Added player actions for reporting an incident, filing a civil claim and requesting a court hearing.
    - Actions are recorded in the World Governor player-action journal.

11. **Sports franchises**
    - Owned franchise management and the franchise acquisition market are foldable.
    - Franchise acquisitions, coach appointments and marquee signings publish player actions to the living-world governance journal.

12. **Mega-projects**
    - The mega-project area is foldable and remains connected to the existing project engine.

13. **Unified Home/Attention surface**
    - Removed the duplicate inline pending-decision stack from the chronology feed.
    - Attention Required is now a compact foldable summary that routes the player to the single Decision Inbox.
    - Individual chronology events remain folded by default with brief summaries and expandable details.

14. **World / Politics / Economy structure**
    - Active World modules, political modules, cities/commercial hubs and sovereign-state information use foldable containers.
    - Constitutional offices are covered by the foldable Political module.
    - Conditional Consequence Engine and Delayed Consequences Scheduler are foldable.

## Architecture principle

The update does not create replacement simulations for banking, investment, companies, politics, justice or real estate. Existing domain engines remain authoritative. The World Governor coordinates their dependencies, records player intent/actions, publishes cross-engine signals, compresses low-value output and reconciles state anomalies.

## Verification

TypeScript parsing/checking was run after the modifications. The changed files no longer produced syntax/type errors in the available compiler output. The project still reports the repository's existing dependency-resolution errors because `node_modules` is not present in the supplied archive.
