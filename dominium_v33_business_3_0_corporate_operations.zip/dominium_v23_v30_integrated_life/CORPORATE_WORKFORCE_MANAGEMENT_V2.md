# DOMINIUM — Corporate Workforce & Management 2.0

The workforce layer connects the existing Living World NPC population to companies as persistent employees.

## Systems
- NPC employee rosters
- Departments and managers
- Salary, skills, performance, potential, morale and engagement
- Recruitment and career records
- Performance reviews
- Promotions and department transfers
- Terminations/resignations
- Labor relations and dispute/strike risk
- Executive succession slates

NPC career records are updated when an NPC joins, leaves or advances within a company.
