# DOMINIUM World Marketplace V10

The legacy fixed marketplace catalog has been removed from runtime use. Offers are generated from a large fictional template space by store/dealership tier.

## Stores
Ordinary department stores, family dealerships, premium stores, marine dealers, aviation houses, luxury houses, technology halls, horology salons, exotic motor galleries and private aviation dealers.

## Inventory rule
Every store/dealership receives exactly 10 fresh offers per simulation tick. Owned possessions are preserved and are not overwritten by refreshes.

## Fictional brands
Runtime marketplace offers use fictional brands only: Aurevon, Veltrix, Novara, Kestrel, Orvane, Solvane, Montara, Elynd, Cavaro, Zenithra, Virelli, Asteron, Ravelle, Quantis, Bellara, Novera, Caldris, Marovelle, Tavren and Ophira.

## Possessions
Owned items have condition, usage hours, resale value, maintenance, passenger capacity and action lists. Vehicles can be driven; boats can cruise and host guests; aircraft can fly to destinations with selected guests; fashion and watches can be worn for social/status effects; technology supports work sessions; collectibles can be displayed.
