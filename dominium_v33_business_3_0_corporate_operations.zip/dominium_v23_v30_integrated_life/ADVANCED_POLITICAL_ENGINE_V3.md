# DOMINIUM Advanced Political Engine 3.0

This release upgrades politics from a collection of UI features into a coordinated living-world simulation layer.

## Core capabilities
- Political capital, grassroots support, donor support, media influence, institutional influence, elite support and public trust.
- Persistent political parties, NPC politicians and internal factions.
- Bills with committee, debate and voting lifecycle, amendments and industry/fiscal impacts.
- Campaign lifecycle: selection, fundraising, media, polling, debate and election.
- Coalition formation and government stability.
- Parliamentary hearings and institutional scrutiny.
- Cabinet appointments and government fiscal dashboard.
- Political scandals, confidence crises, public responses and accountability.
- Conflict-of-interest declarations and recusals.
- Diplomatic missions and treaty negotiation.
- Political action history.
- Monthly autonomous NPC/faction/campaign/bill evolution.
- Economic conditions influence polling and government stability.
- Political outcomes create events/news and are sent to the World Governor action journal.

## World integration
Politics is coordinated through the existing World Governor and feeds the economy, government, NPCs, companies, social system and world event/history layers. It does not replace the existing political engine; it extends the existing `GameState.politics` structure through `politics.advanced` so existing saves remain structurally compatible.

## UI
The Politics Hub includes a foldable `Political Engine 3.0` workspace with:
- political power dashboard
- legislation
- campaign lifecycle
- actors/factions
- coalitions/opposition
- government/cabinet/budget
- ethics/scandals
- diplomacy
- political chronicle

Existing political career, campaign, party, governance, constitutional and government views remain available.
