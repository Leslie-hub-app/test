# Dominium Government Living Organization v6

This layer turns government into a persistent NPC organization integrated with the monthly living-world simulation.

## Systems
- Ministries with NPC ministers, permanent secretaries and civil servants drawn from the existing NPC engine.
- Parliament with NPC members, parties, bills and voting support.
- Government budgets, departmental allocations, deficits and sovereign debt pressure.
- Public projects and government procurement linked to companies and employment.
- Tax policy feeding household, corporate and government finances.
- Central-bank policy with an independence constraint and monetary transmission into the living economy.
- Elections and recurring election cycles.
- Scandals, investigations, protests and strikes with approval effects.
- Approval tracked across demographic groups.
- International diplomacy, treaties, trade deals and sanctions.
- Persistent government history and narrative events pushed into the canonical event feed.
- Monthly propagation into country approval, infrastructure, employment, fiscal conditions, banking, corporate activity and the wider living world.

## Design rule
Political authority is permission-based. A player can only exercise powers attached to the office they actually hold. The central bank remains operationally independent unless the simulated constitutional arrangement explicitly allows political control.
