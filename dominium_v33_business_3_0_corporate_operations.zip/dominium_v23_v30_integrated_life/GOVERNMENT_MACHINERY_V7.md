# DOMINIUM — Government Machinery v7

This expansion turns government from a collection of country statistics into a functioning political institution.

## Systems
- Cabinet meetings and ministry policy proposals
- Parliamentary committees and party whips
- Line-item budget proposals and voting
- Taxation by category
- Treasury debt issuance
- Competitive procurement tenders using the existing company universe
- Corporate lobbying records and influence
- Corruption/procurement/constitutional investigations
- Courts and constitutional cases
- Constitutional constraints
- Political crisis escalation
- Treaty negotiation and ratification

## Causal loop
Government decisions -> taxes/spending/regulation -> companies/banks/households -> employment/consumption/investment -> macro conditions -> approval -> elections -> government.
