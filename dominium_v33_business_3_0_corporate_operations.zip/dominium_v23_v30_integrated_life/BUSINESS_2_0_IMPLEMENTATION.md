# DOMINIUM Business 2.0 — Full Operational Management

Business 2.0 extends the canonical `Company` and Business World systems with an operational layer rather than duplicating companies.

Implemented operational entities: departments, products/services, pricing, inventory, suppliers, customers, sales pipeline, contracts, payroll, HR state, marketing campaigns, physical locations/leases, equipment, financing and competitors.

Management can be `OWNER_MANAGED` or `EXECUTIVE_DELEGATED`, and individual departments can be delegated independently. Monthly simulation calculates demand, capacity, units sold, contract revenue, COGS, payroll, departmental budgets, leases, equipment costs, financing payments, marketing spend, operating profit, inventory and customer satisfaction. Important changes are sent to the World Governor and financial ledger.

The UI exposes these systems through foldable Business 2.0 controls in the existing Living Business Ecosystem panel.
