# DOMINIUM Business Expansion — Living Business Ecosystem

Implemented on top of the existing company/corporate systems without creating a second company model.

## Core integration
BusinessWorldState is an optional GameState extension and the existing `companies[]` remain authoritative for company identity, ownership, valuation and core financials.

Monthly simulation now evaluates:
- customer demand and customer base
- supplier health/disruption
- competitor pressure and market share
- department health
- employee skill, performance, morale, loyalty and turnover pressure
- company revenue, expenses, cash reserve, profit and valuation
- commercial opportunities and contracts
- working-capital crisis signals

## Playable business actions
The Business Empire hub now contains a foldable Living Business Ecosystem with:
- company selector
- living operations
- employee roster and hiring/termination
- contracts and opportunities with accept/decline actions
- competitive/market position
- business risk signals

## Existing systems reused
The expansion intentionally builds on:
- Company / ownership model
- Corporate management
- Corporate workforce
- Boardroom 2.0
- Capital markets
- M&A
- Real estate
- Banking/credit
- Financial ledger
- World Governor
- Life/career/NPC systems

## Living-world propagation
Material business developments publish through the World Governor action journal and are surfaced as Business events. Business state can therefore feed employment, finance, real estate, banking, politics and social systems without a second isolated simulation.

## Long-horizon safety
The business engine is monthly and bounded: employee rosters are capped during seeding, open opportunities are capped per company, and expired opportunities are removed from active gameplay. Routine operations are aggregated instead of generating player notifications for every ordinary transaction.
