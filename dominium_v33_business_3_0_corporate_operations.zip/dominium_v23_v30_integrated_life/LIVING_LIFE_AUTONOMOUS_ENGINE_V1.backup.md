# DOMINIUM Living Life Autonomous Engine V1

Adds a monthly autonomous personal-life layer to the existing Life Engine. It generates bounded, deterministic-by-state events across NPC interactions, household issues, career situations, relationships, health, travel and personal finance.

Important events can create player decisions; low-value activity is recorded and surfaced through the existing Governor/event controls rather than flooding the inbox. Events are written to Life Biography and the World Governor action journal. The engine is intentionally a coordinator and does not replace existing domain engines.
