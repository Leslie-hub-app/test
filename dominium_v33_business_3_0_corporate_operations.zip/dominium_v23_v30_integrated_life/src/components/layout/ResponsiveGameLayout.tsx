import React, { useEffect, useRef, useState } from 'react';
import { GameState } from '../../types';
import { FloatingStatusBar, StatusBarPosition } from './FloatingStatusBar';
import { Activity, Grip, X } from 'lucide-react';

interface ResponsiveGameLayoutProps {
  state: GameState;
  statusBarPosition: StatusBarPosition;
  onToggleStatusBarPosition: () => void;
  onOpenStatusDetail: (attrName: string) => void;
  onOpenPowerProfile?: () => void;
  onOpenProgressionProfile?: () => void;
  onOpenDecisionInbox?: () => void;
  onOpenObjectives?: () => void;
  children: React.ReactNode;
}

export const ResponsiveGameLayout: React.FC<ResponsiveGameLayoutProps> = ({
  state, statusBarPosition, onToggleStatusBarPosition, onOpenStatusDetail,
  onOpenPowerProfile, onOpenProgressionProfile, onOpenDecisionInbox, onOpenObjectives, children
}) => {
  const [open, setOpen] = useState(false);
  const [position, setPosition] = useState(() => {
    try { return JSON.parse(localStorage.getItem('dominium_vitals_position') || 'null') || { x: window.innerWidth - 300, y: 130 }; }
    catch { return { x: 20, y: 130 }; }
  });
  const drag = useRef<{ dx: number; dy: number } | null>(null);

  useEffect(() => {
    try { localStorage.setItem('dominium_vitals_position', JSON.stringify(position)); } catch {}
  }, [position]);

  useEffect(() => {
    const move = (e: PointerEvent) => {
      if (!drag.current) return;
      const x = Math.max(8, Math.min(window.innerWidth - 78, e.clientX - drag.current.dx));
      const y = Math.max(76, Math.min(window.innerHeight - 70, e.clientY - drag.current.dy));
      setPosition({ x, y });
    };
    const up = () => { drag.current = null; };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
  }, []);

  const startDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    drag.current = { dx: e.clientX - position.x, dy: e.clientY - position.y };
  };

  return (
    <div className="relative min-h-[calc(100vh-120px)] w-full">
      <main id="central-game-content" className="min-w-0 px-2 sm:px-4 md:px-6 py-2.5 sm:py-3.5 space-y-3.5 sm:space-y-4 safe-bottom-pad overflow-y-auto min-h-[calc(100vh-120px)]">
        <div className="w-full max-w-5xl mx-auto">{children}</div>
      </main>

      {/* Persistent draggable Vitals HUD. It is an overlay, never part of page flow. */}
      <div
        className="fixed z-[60] select-none"
        style={{ left: position.x, top: position.y }}
        aria-label="Floating Vitals and Status HUD"
      >
        {!open ? (
          <button
            onClick={() => setOpen(true)}
            onPointerDown={startDrag}
            className="group w-14 h-14 rounded-2xl bg-zinc-950/95 backdrop-blur-md border border-amber-400/40 shadow-2xl flex flex-col items-center justify-center cursor-grab active:cursor-grabbing hover:border-amber-300 transition-all"
            title="Open Vitals & Status HUD — drag to move"
          >
            <Activity className="w-5 h-5 text-amber-400" />
            <span className="text-[8px] font-black text-zinc-300 mt-0.5">VITALS</span>
            <span className="text-[8px] font-mono text-emerald-400">{Math.round(state.character.attributes.health)}%</span>
          </button>
        ) : (
          <div className="relative">
            <div onPointerDown={startDrag} className="absolute -top-5 left-0 right-0 h-5 flex items-center justify-center cursor-grab active:cursor-grabbing text-zinc-500 hover:text-amber-400">
              <Grip className="w-4 h-4" />
            </div>
            <div className="w-[min(88vw,300px)] max-h-[78vh] overflow-hidden rounded-2xl border border-amber-400/25 shadow-2xl bg-zinc-950/95 backdrop-blur-xl">
              <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-800">
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-400">Vitals & Status</span>
                <button onClick={() => setOpen(false)} className="w-7 h-7 rounded-lg bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-400" aria-label="Collapse Vitals HUD"><X className="w-3.5 h-3.5" /></button>
              </div>
              <div className="max-h-[calc(78vh-42px)] overflow-y-auto">
                <FloatingStatusBar
                  state={state}
                  position={statusBarPosition}
                  onTogglePosition={onToggleStatusBarPosition}
                  onOpenStatusDetail={onOpenStatusDetail}
                  onOpenPowerProfile={onOpenPowerProfile}
                  onOpenProgressionProfile={onOpenProgressionProfile}
                  onOpenDecisionInbox={onOpenDecisionInbox}
                  onOpenObjectives={onOpenObjectives}
                  isCollapsed={false}
                  onToggleCollapse={() => setOpen(false)}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
