import React,{useState} from 'react';
import {GameState} from '../../types';
import {ensureLifeExpansion,performLifeHealthRoutine,performStudyAction,performSocialInteraction,configureHouseholdPlan,travelWithPossession} from '../../engine/lifeExpansionEngine';
import {FoldableSection} from '../FoldableSection';
import {LivingLifeWorldView} from './LivingLifeWorldView';
import {HeartPulse,BookOpen,Users,Wallet,Plane,CheckCircle2} from 'lucide-react';

export const LifePersonalCommandView:React.FC<{state:GameState;onUpdateState?:(s:GameState)=>void}>=({state,onUpdateState})=>{
 const e=ensureLifeExpansion(state); const life=state.lifeSystem!; const [msg,setMsg]=useState('');
 const act=(r:any)=>{setMsg(r.message);onUpdateState?.({...state});};
 const relationshipOptions=state.relationships.filter(r=>r.alive).slice(0,12);
 const possessions=life.marketplaceInventory.filter(a=>a.purchased);
 const [budget,setBudget]=useState(e.householdPlan.monthlyBudget); const [reserve,setReserve]=useState(e.householdPlan.reserveTarget);
 return <div className="space-y-4"><LivingLifeWorldView state={state}/>
  {msg&&<div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/30 text-xs text-emerald-200 flex gap-2"><CheckCircle2 className="w-4 h-4"/>{msg}</div>}
  <FoldableSection title="Personal Health & Vitality" subtitle="Structured monthly health maintenance and recovery actions.">
   <div className="grid grid-cols-2 md:grid-cols-5 gap-2">{[['checkup','Medical check-up'],['nutrition','Nutrition plan'],['sleep','Sleep reset'],['mental','Mental reset'],['fitness','Fitness block']].map(([id,label])=><button key={id} onClick={()=>act(performLifeHealthRoutine(state,id))} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-left"><HeartPulse className="w-4 h-4 text-rose-400 mb-2"/><b className="text-xs">{label}</b><div className="text-[10px] text-zinc-500 mt-1">Once monthly</div></button>)}</div>
  </FoldableSection>
  <FoldableSection title="Education & Study Studio" summary={life.currentDegreeStatus?`GPA ${life.currentDegreeStatus.gpa.toFixed(2)} · ${life.currentDegreeStatus.academicStanding}`:'No active tertiary programme'}>
   {life.currentDegreeStatus?<div className="grid grid-cols-2 md:grid-cols-4 gap-2">{['Lecture attendance','Library research','Assignment sprint','Exam preparation'].map(a=><button key={a} onClick={()=>act(performStudyAction(state,a,8))} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-left"><BookOpen className="w-4 h-4 text-sky-400 mb-2"/><b className="text-xs">{a}</b><div className="text-[10px] text-zinc-500">8 hours · once/month</div></button>)}</div>:<p className="text-xs text-zinc-500">Enroll in a university programme to unlock structured study actions.</p>}
  </FoldableSection>
  <FoldableSection title="Relationships & Social Life" subtitle={`${relationshipOptions.length} active people available for meaningful monthly interactions`}>
   <div className="grid grid-cols-1 md:grid-cols-2 gap-2">{relationshipOptions.map(r=><div key={r.id} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800"><div className="flex justify-between"><div><b className="text-xs">{r.name}</b><div className="text-[10px] text-zinc-500">{r.relation} · Love {r.love} · Trust {r.trust}</div></div><Users className="w-4 h-4 text-rose-400"/></div><div className="flex flex-wrap gap-1.5 mt-2">{['call','visit','deep_talk','gift','apologize'].map(a=><button key={a} onClick={()=>act(performSocialInteraction(state,r.id,a))} className="px-2 py-1 rounded-lg bg-zinc-800 text-[9px] font-bold">{a.replace('_',' ')}</button>)}</div></div>)}</div>
  </FoldableSection>
  <FoldableSection title="Household Cashflow & Solvency" subtitle={`Budget $${e.householdPlan.monthlyBudget.toLocaleString()}/mo · Reserve target $${e.householdPlan.reserveTarget.toLocaleString()}`}>
   <div className="grid grid-cols-1 md:grid-cols-3 gap-2"><div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800"><Wallet className="w-4 h-4 text-amber-400 mb-2"/><div className="text-[10px] text-zinc-500">Liquid cash</div><b>${state.finances.cash.toLocaleString()}</b></div><label className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">Monthly budget<input type="number" value={budget} onChange={x=>setBudget(Number(x.target.value))} className="mt-2 w-full bg-zinc-900 p-2 rounded-lg"/></label><label className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">Reserve target<input type="number" value={reserve} onChange={x=>setReserve(Number(x.target.value))} className="mt-2 w-full bg-zinc-900 p-2 rounded-lg"/></label></div><button onClick={()=>act(configureHouseholdPlan(state,budget,reserve))} className="mt-2 px-4 py-2 rounded-xl bg-amber-400 text-zinc-950 text-xs font-black">Save household plan</button>
  </FoldableSection>
  <FoldableSection title="Possessions & Personal Travel" subtitle={`${possessions.length} owned possessions available for use`}>
   {possessions.length?<div className="grid grid-cols-1 md:grid-cols-2 gap-2">{possessions.map(a=><div key={a.id} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800"><div className="flex gap-2"><Plane className="w-4 h-4 text-sky-400"/><div><b className="text-xs">{a.brand} {a.name}</b><div className="text-[10px] text-zinc-500">{a.category} · maintenance ${a.monthlyMaintenance.toLocaleString()}/mo</div></div></div><button onClick={()=>act(travelWithPossession(state,a.id,'Meridian City',[]))} className="mt-2 px-3 py-1.5 rounded-lg bg-zinc-800 text-[10px] font-bold">Use / Travel</button></div>)}</div>:<p className="text-xs text-zinc-500">Purchase possessions through the marketplace to unlock personal use actions.</p>}
  </FoldableSection>
 </div>
}
