import React from 'react';
import { CalendarDays, Clock3, Users, Plane, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { GameState } from '../../types';
import { FoldableSection } from '../FoldableSection';
import { getDailyLifeSummary, initializeDailyLifeSchedule } from '../../engine/personalDailyLifeScheduler';

export const PersonalDailyLifeView:React.FC<{state:GameState}>=({state})=>{
 const l=initializeDailyLifeSchedule(state); const summary=getDailyLifeSummary(state); const today=l.currentDay;
 const upcoming=l.activities.filter(a=>a.day>today&&a.status==='SCHEDULED').sort((a,b)=>a.day-b.day||a.startHour-b.startHour).slice(0,10);
 const interruptions=l.interruptions.filter(i=>!i.resolved).sort((a,b)=>b.importance-a.importance).slice(0,6);
 return <FoldableSection title="Personal Daily-Life Scheduler" summary={`${summary.completed}/${summary.days} days simulated · ${summary.importantInterruptions} important interruptions · ${summary.aggregated} low-value activities aggregated`} subtitle="Your monthly time allocation is converted into daily routines, workdays, weekends, appointments, NPC availability, travel windows and interruptions. The World Governor suppresses routine noise and surfaces only meaningful deviations.">
   <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
    <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800"><div className="text-[9px] text-zinc-500">DAY</div><b className="text-lg">{summary.day}/{summary.days}</b></div>
    <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800"><div className="text-[9px] text-zinc-500">SCHEDULED</div><b className="text-lg">{summary.scheduled}</b></div>
    <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800"><div className="text-[9px] text-zinc-500">NPC WINDOWS</div><b className="text-lg">{Object.keys(l.npcAvailability).length}</b></div>
    <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800"><div className="text-[9px] text-zinc-500">TRAVEL</div><b className="text-lg">{summary.travelWindows}</b></div>
   </div>
   {interruptions.length>0 && <div className="mb-4"><div className="text-[10px] uppercase tracking-widest font-bold text-amber-400 mb-2">Meaningful interruptions</div><div className="space-y-2">{interruptions.map(i=><div key={i.id} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex gap-3"><AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5"/><div><b className="text-xs">Day {i.day} · {i.title}</b><div className="text-[10px] text-zinc-500 mt-1">{i.summary}</div></div></div>)}</div></div>}
   <div className="text-[10px] uppercase tracking-widest font-bold text-zinc-500 mb-2">Upcoming scheduled life</div>
   <div className="space-y-2">{upcoming.map(a=><div key={a.id} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center gap-3"><CalendarDays className="w-4 h-4 text-amber-400"/><div className="flex-1"><b className="text-xs">Day {a.day} · {a.title}</b><div className="text-[10px] text-zinc-500">{String(Math.floor(a.startHour)).padStart(2,'0')}:00 · {a.durationHours}h · {a.source.toLowerCase()}</div></div>{a.status==='COMPLETED'?<CheckCircle2 className="w-4 h-4 text-emerald-400"/>:<Clock3 className="w-4 h-4 text-zinc-600"/>}</div>)}
   {upcoming.length===0&&<div className="text-xs text-zinc-500 p-4 border border-dashed border-zinc-800 rounded-xl">The current simulated month has been fully scheduled and processed. The next simulation month will generate a fresh schedule.</div>}
 </div>
 </FoldableSection>
}
