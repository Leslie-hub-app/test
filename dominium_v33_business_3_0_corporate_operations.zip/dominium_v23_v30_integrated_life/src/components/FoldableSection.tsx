import React, { useEffect, useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

export const FoldableSection: React.FC<{title:string; subtitle?:string; defaultOpen?:boolean; badge?:string; children:React.ReactNode; className?:string}> = ({title,subtitle,defaultOpen=true,badge,children,className=''}) => {
  const [open,setOpen]=useState(defaultOpen);
  useEffect(()=>{ const close=()=>setOpen(false); window.addEventListener('dominium-hub-change',close); return()=>window.removeEventListener('dominium-hub-change',close); },[]);
  return <section className={`bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden ${className}`}>
    <button type="button" onClick={()=>setOpen(v=>!v)} className="w-full px-4 py-3 flex items-center justify-between gap-3 text-left hover:bg-zinc-800/40 transition-colors">
      <div className="min-w-0"><div className="flex items-center gap-2"><span className="text-sm font-black text-zinc-100 truncate">{title}</span>{badge&&<span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/25">{badge}</span>}</div>{subtitle&&<div className="text-[10px] text-zinc-500 mt-0.5 truncate">{subtitle}</div>}</div>
      {open?<ChevronDown className="w-4 h-4 text-amber-400 shrink-0"/>:<ChevronRight className="w-4 h-4 text-zinc-500 shrink-0"/>}
    </button>
    {open&&<div className="p-4 pt-1">{children}</div>}
  </section>
}
