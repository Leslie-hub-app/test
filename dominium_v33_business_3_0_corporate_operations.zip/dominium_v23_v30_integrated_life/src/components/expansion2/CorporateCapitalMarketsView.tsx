import React, { useState } from 'react';
import { GameState } from '../../types';
import { ensureCorporateCapitalMarketsState, conveneAGM, createCEOCompensationPackage, launchActivistCampaign, issueCorporateDebt, launchSecondaryOffering, launchIPO, launchCrossBorderMABid, openAntitrustCase, submitGovernmentContractBid, startCorporateLobbying } from '../../engine/corporateCapitalMarketsEngine';
import { FoldableSection } from '../FoldableSection';
import { Landmark, Megaphone, Scale, ShieldAlert, BriefcaseBusiness, BadgeDollarSign, Gavel, History } from 'lucide-react';

export const CorporateCapitalMarketsView: React.FC<{state:GameState; companyId:string; onStateChange?:()=>void}> = ({state,companyId,onStateChange}) => {
 const s=ensureCorporateCapitalMarketsState(state); const c=state.companies.find(x=>x.id===companyId); const [amount,setAmount]=useState(10000000); const [options,setOptions]=useState(10000); const [budget,setBudget]=useState(100000); const [shares,setShares]=useState(100000); const [ipoCompanyId,setIpoCompanyId]=useState(''); const [price,setPrice]=useState(c?.sharePrice||10); const [toast,setToast]=useState('');
 if(!c) return null;
 const notify=(m:string)=>{setToast(m);setTimeout(()=>setToast(''),3000);onStateChange?.()};
 const invoke=(fn:()=>{success:boolean;message:string})=>notify(fn().message);
 const activeActivism=s.activistCampaigns.filter(x=>x.status==='ACTIVE'); const debt=s.debtInstruments.filter(x=>x.companyId===companyId&&x.outstanding>0); const cases=s.antitrustCases.filter(x=>x.companyId===companyId&&x.status==='OPEN'); const bankrupt=s.bankruptcyCases.find(x=>x.companyId===companyId&&x.status==='ACTIVE');
 return <div className="space-y-4">
  {toast&&<div className="p-3 rounded-xl bg-amber-400/10 border border-amber-400/30 text-xs font-bold text-amber-300">{toast}</div>}
  <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
   <FoldableSection title="AGM & Shareholder Politics" subtitle="Connected to the living corporate, political and market world." defaultOpen={true}>

    <h3 className="font-black text-zinc-100 flex items-center gap-2"><Landmark className="w-4 h-4 text-amber-400"/> AGM & shareholder politics</h3>
    <p className="text-[10px] text-zinc-500">AGMs occur annually in the monthly simulation. Votes aggregate player, founder, institutional and other shareholder positions.</p>
    <button onClick={()=>invoke(()=>conveneAGM(state,c.id))} className="w-full py-2 rounded-lg bg-amber-400 text-zinc-950 text-xs font-black">Convene AGM Now</button>
    <div className="text-[10px] text-zinc-500">AGMs recorded: {s.agms.filter(a=>a.companyId===c.id).length}</div>
    <div className="space-y-1 max-h-32 overflow-auto">{s.agms.filter(a=>a.companyId===c.id).slice(-4).reverse().map(a=><div key={a.id} className="p-2 bg-zinc-950 rounded-lg text-[10px]">Tick {a.scheduledTick}: {a.resolutions.filter(v=>v.passed).length}/{a.resolutions.length} passed • CEO evaluation {a.ceoEvaluation.toFixed(0)}</div>)}</div>
   
</FoldableSection>
   <FoldableSection title="CEO Compensation & Options" subtitle="Connected to the living corporate, political and market world." defaultOpen={false}>

    <h3 className="font-black text-zinc-100 flex items-center gap-2"><BadgeDollarSign className="w-4 h-4 text-emerald-400"/> CEO compensation & options</h3>
    <div className="grid grid-cols-2 gap-2"><input type="number" value={amount} onChange={e=>setAmount(Number(e.target.value))} className="bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs" placeholder="Base salary"/><input type="number" value={options} onChange={e=>setOptions(Number(e.target.value))} className="bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs" placeholder="Options"/></div>
    <input type="number" value={25} className="hidden" readOnly/>
    <button onClick={()=>invoke(()=>createCEOCompensationPackage(state,c.id,amount,25,options))} className="w-full py-2 rounded-lg bg-zinc-800 text-zinc-100 text-xs font-black">Approve package (25% target bonus)</button>
    {s.ceoCompensation[c.id]&&<div className="p-2 bg-zinc-950 rounded-lg text-[10px] text-zinc-400">Base ${s.ceoCompensation[c.id].baseSalary.toLocaleString()} • {s.ceoCompensation[c.id].targetBonusPercent}% bonus • {s.ceoCompensation[c.id].vestedOptions.toLocaleString()}/{s.ceoCompensation[c.id].optionShares.toLocaleString()} vested options • strike ${s.ceoCompensation[c.id].strikePrice.toFixed(2)}</div>}
   
</FoldableSection>
   <FoldableSection title="Activist Campaigns" subtitle="Connected to the living corporate, political and market world." defaultOpen={false}>

    <h3 className="font-black text-zinc-100 flex items-center gap-2"><Megaphone className="w-4 h-4 text-fuchsia-400"/> Activist campaigns</h3>
    <button onClick={()=>invoke(()=>launchActivistCampaign(state,c.id))} className="w-full py-2 rounded-lg bg-fuchsia-500 text-zinc-950 text-xs font-black">Launch activist campaign</button>
    {activeActivism.filter(a=>a.companyId===c.id).map(a=><div key={a.id} className="p-2 bg-zinc-950 rounded-lg text-[10px]">{a.stage.replaceAll('_',' ')} • support {a.supportPercent.toFixed(0)}% • demand: {a.demand}</div>)}
   
</FoldableSection>
  </div>
  <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
   <FoldableSection title="Debt & Capital Markets" subtitle="Connected to the living corporate, political and market world." defaultOpen={true}>
<h3 className="font-black text-zinc-100 flex items-center gap-2"><BadgeDollarSign className="w-4 h-4 text-blue-400"/> Debt & capital markets</h3><div className="grid grid-cols-2 gap-2"><input type="number" value={amount} onChange={e=>setAmount(Number(e.target.value))} className="bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"/><button onClick={()=>invoke(()=>issueCorporateDebt(state,c.id,amount))} className="py-2 rounded-lg bg-zinc-800 text-xs font-black">Issue debt</button></div>{debt.map(d=><div key={d.id} className="p-2 bg-zinc-950 rounded-lg text-[10px]">${d.outstanding.toLocaleString()} outstanding • {d.couponRate.toFixed(2)}% • matures tick {d.maturityTick} • {d.creditRating}</div>)}
</FoldableSection>
   <FoldableSection title="Equity Offerings" subtitle="Connected to the living corporate, political and market world." defaultOpen={false}>
<h3 className="font-black text-zinc-100 flex items-center gap-2"><BriefcaseBusiness className="w-4 h-4 text-amber-400"/> Equity offerings</h3><div className="grid grid-cols-3 gap-2"><input type="number" value={shares} onChange={e=>setShares(Number(e.target.value))} className="bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"/><input type="number" value={price} onChange={e=>setPrice(Number(e.target.value))} className="bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"/><button onClick={()=>invoke(()=>launchSecondaryOffering(state,c.id,shares,5))} className="py-2 rounded-lg bg-zinc-800 text-xs font-black">Secondary offer</button></div><div className="space-y-1">{s.offerings.filter(o=>o.companyId===c.id).slice(-4).map(o=><div key={o.id} className="text-[10px] p-2 bg-zinc-950 rounded-lg">{o.type} • {o.stage} • {o.sharesOffered.toLocaleString()} shares @ ${o.offerPrice.toFixed(2)}</div>)}</div>
</FoldableSection>
  </div>
  <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
   <FoldableSection title="Antitrust & Competition" subtitle="Connected to the living corporate, political and market world." defaultOpen={false}>
<h3 className="font-black text-zinc-100 flex items-center gap-2"><Scale className="w-4 h-4 text-red-400"/> Antitrust</h3><button onClick={()=>invoke(()=>openAntitrustCase(state,c.id))} className="w-full py-2 rounded-lg bg-zinc-800 text-xs font-black">Open competition case</button>{cases.map(x=><div key={x.id} className="p-2 bg-zinc-950 rounded-lg text-[10px]">{x.authority} • {x.stage} • risk {x.risk.toFixed(0)} • fine exposure ${x.fineExposure.toLocaleString()}</div>)}
</FoldableSection>
   <FoldableSection title="Government Procurement" subtitle="Connected to the living corporate, political and market world." defaultOpen={false}>
<h3 className="font-black text-zinc-100 flex items-center gap-2"><Gavel className="w-4 h-4 text-blue-400"/> Government procurement</h3><input value="National Infrastructure Agency" readOnly className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"/><button onClick={()=>invoke(()=>submitGovernmentContractBid(state,c.id,'National Infrastructure Agency',Math.max(1000000,amount),12))} className="w-full py-2 rounded-lg bg-blue-500 text-zinc-950 text-xs font-black">Submit contract bid</button>{s.governmentContracts.filter(x=>x.companyId===c.id).slice(-3).map(x=><div key={x.id} className="p-2 bg-zinc-950 rounded-lg text-[10px]">{x.agency} • {x.stage} • ${x.contractValue.toLocaleString()} • performance {x.performanceScore.toFixed(0)}</div>)}
</FoldableSection>
   <FoldableSection title="Lobbying & Financial Distress" subtitle="Connected to the living corporate, political and market world." defaultOpen={false}>
<h3 className="font-black text-zinc-100 flex items-center gap-2"><ShieldAlert className="w-4 h-4 text-amber-400"/> Lobbying & financial distress</h3><div className="flex gap-2"><input type="number" value={budget} onChange={e=>setBudget(Number(e.target.value))} className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"/><button onClick={()=>invoke(()=>startCorporateLobbying(state,c.id,budget))} className="py-2 px-3 rounded-lg bg-zinc-800 text-xs font-black">Fund</button></div>{bankrupt&&<div className="p-2 rounded-lg bg-red-950/40 border border-red-900 text-[10px]">Distress: {bankrupt.stage.replaceAll('_',' ')} • debt at filing ${bankrupt.debtAtFiling.toLocaleString()} • recovery {bankrupt.creditorRecoveryEstimate}%</div>}<div className="text-[10px] text-zinc-500">Active lobbying programs: {s.lobbyingPrograms.filter(x=>x.companyId===c.id&&x.status==='ACTIVE').length} • bankruptcy cases: {s.bankruptcyCases.filter(x=>x.companyId===c.id).length}</div>
</FoldableSection>
  </div>
  <FoldableSection title="IPO & Cross-Border M&A" subtitle="Connected to the living corporate, political and market world." defaultOpen={true}>
<h3 className="font-black text-zinc-100 flex items-center gap-2"><BriefcaseBusiness className="w-4 h-4 text-emerald-400"/> IPO & cross-border M&A</h3><div className="grid grid-cols-1 md:grid-cols-4 gap-2"><select value={ipoCompanyId} onChange={e=>setIpoCompanyId(e.target.value)} className="bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"><option value="">Select private company for IPO</option>{state.companies.filter(x=>!x.isPublic).slice(0,30).map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select><input type="number" value={shares} onChange={e=>setShares(Number(e.target.value))} className="bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"/><button disabled={!ipoCompanyId} onClick={()=>invoke(()=>launchIPO(state,ipoCompanyId,shares,Math.max(1,price)))} className="py-2 rounded-lg bg-emerald-500 text-zinc-950 text-xs font-black disabled:opacity-40">Launch IPO</button><button onClick={()=>{const foreign=state.companies.find(x=>x.isPublic&&x.country!==c.country&&x.id!==c.id); notify(foreign?launchCrossBorderMABid(state,c.id,foreign.id,30).message:'No foreign public target available.')}} className="py-2 rounded-lg bg-zinc-800 text-xs font-black">Cross-border M&A</button></div><div className="grid md:grid-cols-2 gap-2">{s.maBids.slice(-6).reverse().map(b=><div key={b.id} className="p-2 bg-zinc-950 rounded-lg text-[10px]"><b>{b.bidderName} → {b.targetName}</b><div className="text-zinc-500">{b.crossBorder?'CROSS-BORDER':''} • {b.stage} • premium {b.premiumPercent}% • antitrust {b.antitrustRisk.toFixed(0)} • political {b.politicalRisk.toFixed(0)}</div></div>)}</div>
</FoldableSection>
  <FoldableSection title="Emergent Corporate History" subtitle="Connected to the living corporate, political and market world." defaultOpen={false}>
<h3 className="font-black text-zinc-100 flex items-center gap-2"><History className="w-4 h-4 text-amber-400"/> Emergent corporate history</h3><div className="grid md:grid-cols-2 gap-2 mt-3 max-h-56 overflow-auto">{s.history.filter(h=>h.companyId===c.id).slice(0,20).map(h=><div key={h.id} className="p-2 bg-zinc-950 rounded-lg text-[10px]"><div className="font-bold text-zinc-200">Tick {h.tick} • {h.title}</div><div className="text-zinc-500 mt-1">{h.description}</div></div>)}</div>
</FoldableSection>
 </div>
}
