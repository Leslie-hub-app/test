import { GameState } from '../types';
import { ensureLifeSystemState, recordLifeBiography } from './lifeEngine';
import { recordWorldPlayerAction } from './worldGovernorCoordinator';

export interface LifeExpansionState {
  version: 1;
  monthly: Record<string, number>;
  healthRoutines: Record<string, number>;
  householdPlan: { reserveTarget: number; monthlyBudget: number; emergencyReserve: number; notes: string[] };
  studyLog: { tick:number; action:string; hours:number; outcome:string }[];
  socialLog: { tick:number; action:string; npcId?:string; outcome:string }[];
  travelLog: { tick:number; assetId:string; destination:string; passengers:string[] }[];
}

const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));
const getTick=(s:GameState)=>s.simulationTick ?? ((s.currentYear||2026)*12+(s.currentMonth||1));
const monthKey=(s:GameState)=>`${s.currentYear}-${s.currentMonth}`;

export function ensureLifeExpansion(state:GameState):LifeExpansionState {
  const life=ensureLifeSystemState(state) as any;
  if(!life.expansion){
    life.expansion={version:1,monthly:{},healthRoutines:{},householdPlan:{reserveTarget:10000,monthlyBudget:Math.max(0,life.lifestyleExpensesMonthly||1200),emergencyReserve:0,notes:[]},studyLog:[],socialLog:[],travelLog:[]};
  }
  return life.expansion;
}

function consumeMonthly(state:GameState, action:string, limit=1):boolean{
  const e=ensureLifeExpansion(state); const key=`${monthKey(state)}:${action}`; const used=e.monthly[key]||0;
  if(used>=limit)return false; e.monthly[key]=used+1; return true;
}

export function performLifeHealthRoutine(state:GameState, routine:string){
  const effects:Record<string,{health:number;stress:number;happiness:number;cost:number}>={
    checkup:{health:3,stress:-2,happiness:2,cost:120}, nutrition:{health:2,stress:-1,happiness:2,cost:80}, sleep:{health:3,stress:-6,happiness:3,cost:0}, mental:{health:1,stress:-8,happiness:4,cost:60}, fitness:{health:4,stress:-4,happiness:3,cost:40}
  };
  const fx=effects[routine]||effects.fitness;
  if(state.finances.cash<fx.cost)return {success:false,message:`Insufficient cash for ${routine}.`};
  if(!consumeMonthly(state,`HEALTH:${routine}`)) return {success:false,message:'This personal health routine has already been used this month.'};
  state.finances.cash-=fx.cost;
  state.character.attributes.health=clamp(state.character.attributes.health+fx.health,0,100);
  state.character.attributes.stress=clamp(state.character.attributes.stress+fx.stress,0,100);
  state.character.attributes.happiness=clamp(state.character.attributes.happiness+fx.happiness,0,100);
  ensureLifeExpansion(state).healthRoutines[`${monthKey(state)}:${routine}`]=getTick(state);
  recordLifeBiography(state,{category:'Lifestyle',title:`Completed ${routine} routine`,description:`Completed a structured ${routine} routine and maintained personal vitality.`,iconName:'HeartPulse',significance:'Minor'});
  recordWorldPlayerAction(state,'LIFE_HEALTH_ROUTINE',`Completed ${routine} routine`,['life','health','wellness'],55);
  return {success:true,message:`Completed ${routine} routine.`};
}

export function performStudyAction(state:GameState, action:string, hours:number){
  const life=ensureLifeSystemState(state); const degree=life.currentDegreeStatus;
  if(!degree)return {success:false,message:'You are not currently enrolled in a tertiary programme.'};
  if(hours<1||hours>40)return {success:false,message:'Study allocation must be between 1 and 40 hours.'};
  if(!consumeMonthly(state,`STUDY:${action}`,1))return {success:false,message:`${action} can only be performed once this month.`};
  const quality=(state.character.attributes.intelligence/100)*0.6+(life.personality.discipline/100)*0.4;
  const gain=hours*(0.006+quality*0.012);
  degree.gpa=Math.max(0,Math.min(4,degree.gpa+gain)); degree.studyHoursMonthly+=hours;
  if(degree.gpa>=3.7)degree.academicStanding='Distinction'; else if(degree.gpa>=2.5)degree.academicStanding='Good Standing'; else degree.academicStanding='Academic Probation';
  life.timeAllocation.studyHours=Math.min(120,life.timeAllocation.studyHours+hours);
  ensureLifeExpansion(state).studyLog.unshift({tick:getTick(state),action,hours,outcome:`GPA trajectory improved to ${degree.gpa.toFixed(2)}`});
  recordWorldPlayerAction(state,'LIFE_STUDY_ACTION',`Studied ${action} for ${hours} hours`,['life','education','career'],55);
  return {success:true,message:`${action} completed for ${hours} hours. GPA trajectory: ${degree.gpa.toFixed(2)}.`};
}

export function performSocialInteraction(state:GameState,npcId:string,action:string){
  if(!consumeMonthly(state,`SOCIAL:${npcId}:${action}`,1))return {success:false,message:'That interaction has already been meaningfully pursued this month.'};
  const rel=state.relationships.find(r=>r.id===npcId||r.name===npcId);
  if(!rel)return {success:false,message:'NPC relationship not found.'};
  const effects:Record<string,{love:number;trust:number;respect:number;happiness:number}>={call:{love:2,trust:3,respect:0,happiness:2},visit:{love:4,trust:3,respect:2,happiness:4},gift:{love:3,trust:1,respect:3,happiness:3},deep_talk:{love:3,trust:5,respect:2,happiness:2},apologize:{love:2,trust:6,respect:2,happiness:1}};
  const fx=effects[action]||effects.visit;
  rel.love=clamp(rel.love+fx.love); rel.trust=clamp(rel.trust+fx.trust); rel.respect=clamp(rel.respect+fx.respect);
  state.character.attributes.happiness=clamp(state.character.attributes.happiness+fx.happiness);
  ensureLifeExpansion(state).socialLog.unshift({tick:getTick(state),action,npcId,outcome:`${rel.name}: love ${rel.love}, trust ${rel.trust}, respect ${rel.respect}`});
  ensureLifeSystemState(state).socialInteractionHistory?.unshift({tick:getTick(state),withNpcId:npcId,action,summary:`${action} with ${rel.name}`});
  recordWorldPlayerAction(state,'LIFE_SOCIAL_INTERACTION',`${action} with ${rel.name}`,['life','relationships','social'],60);
  return {success:true,message:`${action} completed with ${rel.name}.`};
}

export function configureHouseholdPlan(state:GameState,monthlyBudget:number,reserveTarget:number){
  const e=ensureLifeExpansion(state); e.householdPlan.monthlyBudget=Math.max(0,monthlyBudget); e.householdPlan.reserveTarget=Math.max(0,reserveTarget); e.householdPlan.notes.unshift(`Plan updated in ${monthKey(state)}.`);
  recordWorldPlayerAction(state,'LIFE_HOUSEHOLD_PLAN',`Household plan: $${monthlyBudget}/mo, reserve $${reserveTarget}`,['life','wealth','banking'],55);
  return {success:true,message:'Household cashflow plan updated.'};
}

export function travelWithPossession(state:GameState,assetId:string,destination:string,passengers:string[]){
  const life=ensureLifeSystemState(state); const asset=life.marketplaceInventory.find(a=>a.id===assetId&&a.purchased); if(!asset)return {success:false,message:'You do not own that possession.'};
  if(!destination.trim())return {success:false,message:'Choose a destination.'};
  const monthlyCost=Math.max(50,Math.round(asset.monthlyMaintenance*0.35+passengers.length*25));
  if(state.finances.cash<monthlyCost)return {success:false,message:`Travel requires $${monthlyCost.toLocaleString()} in operating costs.`};
  state.finances.cash-=monthlyCost; state.character.attributes.happiness=clamp(state.character.attributes.happiness+5); state.character.attributes.stress=clamp(state.character.attributes.stress-4);
  ensureLifeExpansion(state).travelLog.unshift({tick:getTick(state),assetId,destination,passengers});
  recordLifeBiography(state,{category:'Lifestyle',title:`Travelled to ${destination}`,description:`Used ${asset.name} for a personal trip with ${passengers.length} passenger(s).`,iconName:'Plane',significance:'Notable'});
  recordWorldPlayerAction(state,'LIFE_TRAVEL',`Travelled to ${destination}`,['life','possessions','world'],65);
  return {success:true,message:`Travelled to ${destination}. Operating cost: $${monthlyCost.toLocaleString()}.`};
}

export function advanceLifeExpansionMonthly(state:GameState){
  const e=ensureLifeExpansion(state); const plan=e.householdPlan; const cash=state.finances.cash;
  if(cash<plan.reserveTarget*0.25) state.character.attributes.stress=clamp(state.character.attributes.stress+2);
  if(cash>=plan.reserveTarget) state.character.attributes.happiness=clamp(state.character.attributes.happiness+1);
  if(e.studyLog.length>100)e.studyLog.length=100; if(e.socialLog.length>150)e.socialLog.length=150; if(e.travelLog.length>100)e.travelLog.length=100;
}
