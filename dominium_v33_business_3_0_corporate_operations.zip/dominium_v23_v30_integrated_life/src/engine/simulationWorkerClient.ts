import { GameState, MonthlySimulationResult } from '../types';

export interface WorkerSimulationResult {
  state: GameState;
  last: MonthlySimulationResult;
  events: any[];
  news: any[];
}

export function advanceMonthsOffMainThread(state: GameState, months: number): Promise<WorkerSimulationResult> {
  if (typeof Worker === 'undefined') return Promise.reject(new Error('Web Workers are not available in this environment.'));
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL('./simulationWorker.ts', import.meta.url), { type: 'module' });
    const cleanup = () => worker.terminate();
    worker.onmessage = (event) => {
      cleanup();
      if (event.data?.ok) resolve(event.data as WorkerSimulationResult);
      else reject(new Error(event.data?.error || 'Simulation worker failed.'));
    };
    worker.onerror = (error) => { cleanup(); reject(error.error || new Error('Simulation worker crashed.')); };
    worker.postMessage({ state, months });
  });
}
