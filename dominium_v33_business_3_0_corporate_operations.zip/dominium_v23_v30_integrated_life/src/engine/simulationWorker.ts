import { advanceOneMonth } from './simulationEngine';

const yieldToWorker = () => new Promise<void>(resolve => setTimeout(resolve, 0));

self.onmessage = async (event: MessageEvent) => {
  const { state, months } = event.data || {};
  try {
    let current = state;
    let last: any = null;
    const events: any[] = [];
    const news: any[] = [];
    const total = Math.max(1, Number(months) || 1);
    for (let i = 0; i < total; i++) {
      last = advanceOneMonth(current);
      current = last.nextState;
      events.push(...last.monthlyEvents);
      news.push(...last.monthlyNews);
      // Cooperative worker yielding prevents one giant 20k+ month task from monopolising the worker event loop.
      if ((i + 1) % 4 === 0) await yieldToWorker();
    }
    self.postMessage({ ok: true, state: current, last, events, news });
  } catch (error) {
    self.postMessage({ ok: false, error: error instanceof Error ? error.message : String(error) });
  }
};
