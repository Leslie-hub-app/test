import { GameState } from '../types';

export type RuntimeMode = 'OFFLINE' | 'ONLINE' | 'ONLINE_SYNCING' | 'ONLINE_DISCONNECTED';
export type SyncStatus = 'LOCAL_ONLY' | 'READY' | 'SYNCING' | 'SYNCED' | 'DISCONNECTED' | 'ERROR';

export interface RuntimeCapabilities {
  localSimulation: true;
  localPersistence: true;
  cloudSave: boolean;
  multiplayer: boolean;
  onlineSocial: boolean;
  onlineEconomy: boolean;
}

export interface RuntimeStatus {
  mode: RuntimeMode;
  syncStatus: SyncStatus;
  lastSyncAt?: string;
  lastError?: string;
  capabilities: RuntimeCapabilities;
}

const RUNTIME_KEY = 'dominium_runtime_v1';
const DEFAULT_CAPABILITIES: RuntimeCapabilities = {
  localSimulation: true,
  localPersistence: true,
  cloudSave: false,
  multiplayer: false,
  onlineSocial: false,
  onlineEconomy: false,
};

export function getRuntimeStatus(): RuntimeStatus {
  const fallback: RuntimeStatus = { mode: typeof navigator !== 'undefined' && navigator.onLine ? 'ONLINE' : 'OFFLINE', syncStatus: 'LOCAL_ONLY', capabilities: DEFAULT_CAPABILITIES };
  if (typeof window === 'undefined') return fallback;
  try {
    const saved = JSON.parse(localStorage.getItem(RUNTIME_KEY) || 'null');
    return { ...fallback, ...(saved || {}), capabilities: { ...DEFAULT_CAPABILITIES, ...(saved?.capabilities || {}) } };
  } catch { return fallback; }
}

export function persistRuntimeStatus(status: RuntimeStatus): void {
  if (typeof window === 'undefined') return;
  try { localStorage.setItem(RUNTIME_KEY, JSON.stringify(status)); } catch { /* local persistence is best effort */ }
}

export function attachRuntimeNetworkListeners(onChange?: (status: RuntimeStatus) => void): () => void {
  if (typeof window === 'undefined') return () => {};
  const update = () => {
    const current = getRuntimeStatus();
    const next: RuntimeStatus = current.mode === 'ONLINE_SYNCING' ? current : {
      ...current,
      mode: navigator.onLine ? 'ONLINE' : 'OFFLINE',
      syncStatus: navigator.onLine ? (current.syncStatus === 'SYNCED' ? 'SYNCED' : current.syncStatus) : 'DISCONNECTED',
    };
    persistRuntimeStatus(next);
    onChange?.(next);
  };
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  update();
  return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); };
}

/** Local-first contract. Online services are optional and can be enabled later without changing simulation engines. */
export interface OnlineSyncAdapter {
  pushSave?(state: GameState): Promise<void>;
  pullSave?(): Promise<GameState | null>;
  sync?(state: GameState): Promise<GameState | null>;
}

export class LocalFirstRuntime {
  private status: RuntimeStatus = getRuntimeStatus();
  constructor(private readonly onlineAdapter?: OnlineSyncAdapter) {}

  getStatus() { return this.status; }

  async synchronize(state: GameState): Promise<GameState> {
    if (!this.onlineAdapter?.sync || typeof navigator !== 'undefined' && !navigator.onLine) {
      this.status = { ...this.status, mode: 'OFFLINE', syncStatus: 'LOCAL_ONLY' };
      persistRuntimeStatus(this.status);
      return state;
    }
    this.status = { ...this.status, mode: 'ONLINE_SYNCING', syncStatus: 'SYNCING', lastError: undefined };
    persistRuntimeStatus(this.status);
    try {
      const remote = await this.onlineAdapter.sync(state);
      this.status = { ...this.status, mode: 'ONLINE', syncStatus: 'SYNCED', lastSyncAt: new Date().toISOString() };
      persistRuntimeStatus(this.status);
      return remote || state;
    } catch (error) {
      // Never block or invalidate an offline game because an online service failed.
      this.status = { ...this.status, mode: 'ONLINE_DISCONNECTED', syncStatus: 'ERROR', lastError: error instanceof Error ? error.message : String(error) };
      persistRuntimeStatus(this.status);
      return state;
    }
  }
}
