import { GameState } from '../types';
import { recordWorldPlayerAction } from './worldGovernorCoordinator';

/**
 * DOMINIUM Politics 4.0
 * Unified political simulation layer. It deliberately consumes the existing
 * politics, politicalGovernance and governmentLiving structures instead of
 * creating a second political universe.
 */

export type Politics4Action =
  | 'LEGISLATURE_INTRODUCE' | 'LEGISLATURE_AMEND' | 'LEGISLATURE_HEARING' | 'LEGISLATURE_VOTE'
  | 'CONSTITUENCY_MEET' | 'PARTY_WHIP' | 'NEGOTIATE_COALITION' | 'CALL_CONFIDENCE'
  | 'APPOINT_CABINET' | 'SET_BUDGET_PRIORITY' | 'DECLARE_CONFLICT' | 'RECUSE'
  | 'CAMPAIGN_STRATEGY' | 'CAMPAIGN_FUNDRAISE' | 'CAMPAIGN_RALLY' | 'CAMPAIGN_DEBATE'
  | 'CAMPAIGN_MEDIA' | 'CAMPAIGN_VOTER_OUTREACH' | 'ELECTION_HOLD' | 'FORMATION_NEGOTIATE'
  | 'POLITICAL_DONOR_MEETING' | 'MEDIA_RESPONSE' | 'DIPLOMATIC_NEGOTIATION'
  | 'ASSIGN_COMMITTEE' | 'SET_WHIP' | 'SHADOW_APPOINT' | 'BILL_VOTE_TRADE' | 'LOBBY_BILL'
  | 'DISTRICT_POLL' | 'SET_ELECTORAL_MODEL' | 'RESHUFFLE_CABINET' | 'NOMINATE_SUCCESSOR'
  | 'TRIGGER_CONSTITUTIONAL_CRISIS' | 'RESOLVE_CONSTITUTIONAL_CRISIS' | 'CONSTITUENCY_CASEWORK';

type Severity = 'LOW'|'MEDIUM'|'HIGH'|'CRITICAL';

export interface VoterBloc4 {
  id:string; name:string; population:number; weight:number; issueWeights:Record<string,number>;
  partyAffinity:Record<string,number>; turnout:number; trust:number; economicSensitivity:number;
}
export interface Politician4 {
  id:string; name:string; partyId:string; factionId:string; constituency:string; ideology:string;
  ambition:number; influenceScore:number; loyalty:number; donorDependence:number; scandalExposure:number; reputation:number;
  attendance:number; competence:number; incumbency:number; policyPreferences:Record<string,number>;
  constituencyInterests:string[]; votingRecord:{billId:string;vote:'FOR'|'AGAINST'|'ABSTAIN';tick:number}[];
  donorIds:string[]; stanceToPlayer:number;
}
export interface BillForecast4 {
  gdpImpactPct:number; employmentImpact:number; inflationImpactPct:number; fiscalImpact:number;
  corporateImpact:number; bankingImpact:number; realEstateImpact:number; householdImpact:number;
  approvalImpact:number; confidence:number; narrative:string;
}
export interface Bill4 {
  id:string; title:string; sponsorId:string; sponsorName:string; chamber:'PARLIAMENT'|'COUNCIL';
  status:'DRAFT'|'COMMITTEE'|'DEBATE'|'VOTING'|'PASSED'|'FAILED'|'VETOED';
  policyArea:string; fiscalCost:number; support:number; opposition:number; amendments:number;
  affectedIndustries:string[]; constituencyEffects:Record<string,number>; forecast:BillForecast4;
  votesFor:number; votesAgainst:number; introducedTick:number; enactedTick?:number;
}
export interface Election4 {
  id:string; office:string; jurisdiction:string; status:'PLANNING'|'CAMPAIGN'|'VOTING'|'CERTIFIED'|'CONTESTED';
  startedTick:number; electionTick:number; candidates:{id:string;name:string;partyId:string;support:number;resources:number;scandal:number}[];
  blocResults:Record<string,Record<string,number>>; turnout:number; winnerId?:string; margin?:number;
}
export interface Government4 {
  id:string; title:string; leaderId:string; parties:string[]; seats:number; majorityNeeded:number;
  stability:number; approval:number; formedTick:number; status:'FORMING'|'ACTIVE'|'MINORITY'|'COLLAPSED'|'CARETAKER';
  coalitionAgreement:string[]; cabinet:{office:string;politicianId:string;competence:number;loyalty:number}[];
  confidenceVotes:number; survivedConfidenceVotes:number;
}
export type ElectoralModel4 = 'FIRST_PAST_THE_POST' | 'PROPORTIONAL_REPRESENTATION' | 'MIXED_MEMBER';
export interface Constituency4 { id:string; name:string; population:number; seats:number; turnout:number; issues:Record<string,number>; polling:Record<string,number>; incumbentId?:string; margin?:number; }
export interface Committee4 { id:string; name:string; chairId:string|null; memberIds:string[]; jurisdiction:string; workload:number; governmentControl:number; }
export interface Whip4 { partyId:string; strength:number; targetBillId?:string; instruction:'FOR'|'AGAINST'|'FREE'; rebels:number; }
export interface ShadowCabinet4 { office:string; politicianId:string; competence:number; attackFocus:string; approval:number; }
export interface BillAmendment4 { id:string; billId:string; sponsorId:string; text:string; fiscalDelta:number; supportEffect:number; status:'PROPOSED'|'ACCEPTED'|'REJECTED'; }
export interface VoteTrade4 { id:string; billId:string; fromPoliticianId:string; toPoliticianId:string; offeredBillId?:string; concession:string; accepted:boolean; }
export interface LobbyingPressure4 { id:string; billId:string; organization:string; influence:number; position:'SUPPORT'|'OPPOSE'; spending:number; compliance:number; disclosed:boolean; }
export interface CabinetReshuffle4 { id:string; tick:number; removedPoliticianId?:string; appointedPoliticianId:string; office:string; reason:string; }
export interface Succession4 { id:string; office:string; candidateId:string; support:number; readiness:number; loyalty:number; status:'EMERGING'|'FRONTRUNNER'|'APPOINTED'|'BLOCKED'; }
export interface ConstitutionalCrisis4 { id:string; type:string; trigger:string; severity:number; legitimacy:number; institutionalActors:string[]; status:'OPEN'|'NEGOTIATING'|'RESOLVED'|'ESCALATED'; resolution?:string; }
export interface Politics4State {
  version:4;
  voterBlocs:VoterBloc4[]; politicians:Politician4[]; bills:Bill4[]; elections:Election4[];
  governments:Government4[]; currentGovernmentId:string|null; donors:{id:string;name:string;type:string;influence:number;compliance:number}[];
  publicOpinion:Record<string,number>; constituencyPressure:Record<string,number>; policyEffects:Record<string,number>;
  politicalCalendar:{nextElectionTick:number;lastElectionTick:number;sessionStartTick:number};
  electoralModel:ElectoralModel4; constituencies:Constituency4[]; committees:Committee4[]; whips:Whip4[]; shadowCabinet:ShadowCabinet4[]; amendments:BillAmendment4[]; voteTrades:VoteTrade4[]; lobbyingPressure:LobbyingPressure4[]; cabinetReshuffles:CabinetReshuffle4[]; succession:Succession4[]; constitutionalCrises:ConstitutionalCrisis4[];
  history:{tick:number;type:string;title:string;summary:string;severity:Severity}[];
  monthlyActions:Record<string,number>;
  mergedSystems:{legacyPolitics:boolean;politicalGovernance:boolean;governmentLiving:boolean;advancedPolitics:boolean};
  lastTick:number;
}

const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));
const tick=(s:GameState)=>s.simulationTick ?? ((s.currentYear||2026)*12+(s.currentMonth||1));
const deepClone=<T,>(x:T):T=>JSON.parse(JSON.stringify(x));
const num=(x:any,d=0)=>Number.isFinite(Number(x))?Number(x):d;
const ideologyScore=(ideology:string,area:string)=>{
  const i=(ideology||'').toLowerCase(), a=area.toLowerCase();
  if(a.includes('health')||a.includes('welfare')||a.includes('labour')) return i.includes('progress')||i.includes('labour')||i.includes('social')?75:45;
  if(a.includes('business')||a.includes('tax')||a.includes('industry')||a.includes('finance')) return i.includes('enterprise')||i.includes('conservative')?75:i.includes('technocrat')?60:40;
  if(a.includes('green')||a.includes('environment')||a.includes('energy')) return i.includes('green')||i.includes('technocrat')?78:42;
  if(a.includes('defence')||a.includes('security')) return i.includes('security')||i.includes('conservative')?78:52;
  if(a.includes('education')||a.includes('technology')) return i.includes('technocrat')||i.includes('progress')?72:55;
  return 55;
};

export function ensurePolitics4(state:GameState):Politics4State{
  const politics:any=state.politics;
  if(!politics.politics4){
    const adv:any=politics.advanced||{};
    const parties:any[]=politics.parties||[];
    const blocs:VoterBloc4[]=[
      {id:'workers',name:'Working Households',population:24,weight:24,issueWeights:{labour:80,welfare:65,cost_of_living:90,housing:75},partyAffinity:{},turnout:68,trust:52,economicSensitivity:85},
      {id:'professionals',name:'Professionals & Middle Income',population:23,weight:23,issueWeights:{tax:65,education:70,housing:72,health:62},partyAffinity:{},turnout:72,trust:58,economicSensitivity:70},
      {id:'business',name:'Business & Investors',population:13,weight:13,issueWeights:{tax:88,business:92,trade:82,regulation:80},partyAffinity:{},turnout:78,trust:55,economicSensitivity:90},
      {id:'youth',name:'Young Voters',population:17,weight:17,issueWeights:{education:84,housing:90,technology:88,environment:72},partyAffinity:{},turnout:55,trust:48,economicSensitivity:65},
      {id:'retirees',name:'Retirees & Pensioners',population:13,weight:13,issueWeights:{health:92,pensions:94,cost_of_living:86,security:70},partyAffinity:{},turnout:81,trust:64,economicSensitivity:76},
      {id:'civic',name:'Civic & Community Organizations',population:10,weight:10,issueWeights:{justice:84,environment:76,public_services:88,integrity:92},partyAffinity:{},turnout:74,trust:57,economicSensitivity:55}
    ];
    const actors:Politician4[]=((adv.actors?.length?adv.actors:[]).length?adv.actors:[]).map((a:any,i:number)=>({
      id:a.id,name:a.name,partyId:parties[i%Math.max(1,parties.length)]?.id||'independent',factionId:a.factionId||'',constituency:['North District','Central District','Coastal District','Industrial District','Metro District'][i%5],ideology:a.keyAgenda||'Centrist',ambition:num(a.ambitionScore,50),influenceScore:num(a.influenceScore,50),loyalty:55,donorDependence:35,scandalExposure:num(a.scandalVulnerability,20),reputation:num(a.reputation,55),attendance:82,competence:65,incumbency:40,policyPreferences:{},constituencyInterests:['jobs','housing','public services'],votingRecord:[],donorIds:[],stanceToPlayer:a.stanceOnPlayer==='Supportive'?35:a.stanceOnPlayer==='Opposed'?-35:0
    }));
    const governmentLiving:any=(state as any).governmentLiving;
    if(actors.length===0 && governmentLiving?.parliamentarians?.length){
      for(const m of governmentLiving.parliamentarians) actors.push({id:m.id,name:m.name,partyId:m.partyId,factionId:'',constituency:m.constituency,ideology:m.ideology,ambition:55,influenceScore:num(m.influence,50),loyalty:num(m.loyalty,55),donorDependence:30,scandalExposure:20,reputation:55,attendance:num(m.attendance,80),competence:65,incumbency:60,policyPreferences:{},constituencyInterests:['jobs','public services'],votingRecord:[],donorIds:[],stanceToPlayer:0});
    }
    const donors=[
      {id:'donor_enterprise',name:'Meridian Enterprise Council',type:'Business Association',influence:78,compliance:88},
      {id:'donor_workers',name:'National Workers Federation',type:'Labour Organization',influence:72,compliance:91},
      {id:'donor_civic',name:'Civic Reform Foundation',type:'Civic Organization',influence:55,compliance:96},
      {id:'donor_investors',name:'Continental Capital Forum',type:'Investor Network',influence:68,compliance:86}
    ];
    const pg:any=(state as any).politicalGovernance;
    const existingGov=governmentLiving?.election;
    politics.politics4={version:4,voterBlocs:blocs,politicians:actors,bills:[],elections:[],governments:[],currentGovernmentId:null,donors,publicOpinion:{economy:55,government:50,integrity:58,services:55},constituencyPressure:{},policyEffects:{},politicalCalendar:{nextElectionTick:num(existingGov?.nextElectionTick,tick(state)+48),lastElectionTick:num(existingGov?.nextElectionTick,0)-48,sessionStartTick:tick(state)},electoralModel:'FIRST_PAST_THE_POST',constituencies:[],committees:[],whips:[],shadowCabinet:[],amendments:[],voteTrades:[],lobbyingPressure:[],cabinetReshuffles:[],succession:[],constitutionalCrises:[],history:[],monthlyActions:{},mergedSystems:{legacyPolitics:true,politicalGovernance:!!pg,governmentLiving:!!governmentLiving,advancedPolitics:!!adv},lastTick:-1};
  }
  const p4=politics.politics4 as Politics4State;
  ensurePolitics41Structures(state,p4);
  syncExistingPoliticalSystems(state,p4);
  return p4;
}

function ensurePolitics41Structures(state:GameState,p:Politics4State){
  if(!p.electoralModel) p.electoralModel='FIRST_PAST_THE_POST';
  if(!p.constituencies?.length){
    const names=['North District','Central District','Coastal District','Industrial District','Metro District','Eastern District','Western District','Southern District'];
    p.constituencies=names.map((name,i)=>({id:`const_${i+1}`,name,population:700000+i*45000,seats:i<3?5:4,turnout:58+i*2,issues:{jobs:80-hyp(i*2),housing:70+i,health:65,education:60,transport:55},polling:{}}));
  }
  for(const c of p.constituencies) for(const party of state.politics.parties||[]) if(c.polling[party.id]===undefined)c.polling[party.id]=num(party.pollingPercentage,25);
  if(!p.committees?.length){
    const defs=[['Finance & Public Accounts','tax,finance,budget'],['Economic Development','business,industry,employment'],['Health & Social Affairs','health,welfare'],['Education & Technology','education,technology'],['Justice & Constitutional Affairs','justice,constitution'],['Infrastructure & Housing','infrastructure,housing'],['Foreign Affairs & Trade','trade,diplomacy']];
    p.committees=defs.map((d,i)=>({id:`committee_${i+1}`,name:d[0],chairId:null,memberIds:p.politicians.slice(i%Math.max(1,p.politicians.length),i%Math.max(1,p.politicians.length)+4).map(x=>x.id),jurisdiction:d[1],workload:35+i*4,governmentControl:55}));
  }
  if(!p.whips?.length) p.whips=(state.politics.parties||[]).map(x=>({partyId:x.id,strength:60,targetBillId:undefined,instruction:'FREE' as const,rebels:0}));
  if(!p.shadowCabinet?.length) p.shadowCabinet=(state.politics.parties||[]).filter(x=>x.id!==state.politics.selectedPartyId).slice(0,5).map((party:any,i:number)=>{const a=p.politicians.find(x=>x.partyId===party.id);return {office:['Finance','Health','Education','Justice','Infrastructure'][i],politicianId:a?.id||'',competence:a?.competence||60,attackFocus:['tax','health','education','justice','housing'][i],approval:50};});
  p.amendments ||= []; p.voteTrades ||= []; p.lobbyingPressure ||= []; p.cabinetReshuffles ||= []; p.succession ||= []; p.constitutionalCrises ||= [];
}
function hyp(i:number){ return i; }

function tock(state:GameState,stage:string){ const order=['SELECTION','FUNDRAISING','MEDIA','POLLING','DEBATE','ELECTION']; return tick(state)+Math.max(1,order.length-Math.max(0,order.indexOf(stage))); }

function syncExistingPoliticalSystems(state:GameState,p:Politics4State){
  const legacy:any=state.politics; const adv:any=legacy.advanced||{}; const pg:any=(state as any).politicalGovernance; const gl:any=(state as any).governmentLiving;
  p.mergedSystems={legacyPolitics:true,politicalGovernance:!!pg,governmentLiving:!!gl,advancedPolitics:!!adv};
  // Existing parties remain the single party registry. Politics 4.0 enriches their voter affinity.
  for(const party of legacy.parties||[]){
    for(const b of p.voterBlocs){
      const ideology=(party.ideology||'').toLowerCase();
      const affinity=ideology.includes('progress')&&['workers','civic','youth'].includes(b.id)?65:ideology.includes('enterprise')&&b.id==='business'?82:ideology.includes('green')&&['youth','civic'].includes(b.id)?78:ideology.includes('technocrat')&&['professionals','youth'].includes(b.id)?72:ideology.includes('conservative')&&['retirees','business'].includes(b.id)?70:50;
      b.partyAffinity[party.id]=affinity;
    }
  }
  // Merge existing Political Governance and Politics 3.0 campaigns without creating duplicate campaigns.
  for(const c of pg?.campaigns||[]){
    if(!p.elections.some((e:any)=>e.id===c.id)) p.elections.push({id:c.id,office:c.office,jurisdiction:c.jurisdiction,status:c.status==='ACTIVE'?'CAMPAIGN':'CERTIFIED',startedTick:num(c.startedTick,0),electionTick:num(c.startedTick,0)+6,candidates:[{id:state.character.id,name:playerName(state),partyId:legacy.selectedPartyId||'independent',support:num(c.polling,50),resources:num(c.budget,0),scandal:0}],blocResults:{},turnout:num((gl?.election?.turnout),65)} as any);
  }
  for(const c of adv?.campaigns||[]){
    if(!p.elections.some((e:any)=>e.id===c.id)) p.elections.push({id:c.id,office:c.office,jurisdiction:legacy.currentOffice.cityOrNation,status:c.stage==='ELECTION'?'VOTING':'CAMPAIGN',startedTick:tick(state),electionTick:tock(state,c.stage),candidates:[{id:state.character.id,name:playerName(state),partyId:legacy.selectedPartyId||'independent',support:num(c.support,50),resources:num(c.budget,0),scandal:num(c.scandalRisk,0)}],blocResults:{},turnout:65} as any);
  }
  // Merge the existing government parliament into Politics 4.0.
  if(gl?.parliamentarians?.length){
    for(const m of gl.parliamentarians){
      const existing=p.politicians.find(x=>x.id===m.id); if(existing){existing.partyId=m.partyId;existing.constituency=m.constituency;existing.ideology=m.ideology;existing.loyalty=num(m.loyalty,existing.loyalty);existing.attendance=num(m.attendance,existing.attendance);existing.influenceScore=num(m.influence,existing.influenceScore);}
    }
  }
  // Mirror enacted Politics 4.0 bills into the existing government bill registry.
  if(gl?.bills){for(const b of p.bills.filter(x=>x.status==='PASSED')) if(!gl.bills.some((x:any)=>x.id===b.id||x.title===b.title)) gl.bills.unshift({id:b.id,title:b.title,sponsorNpcId:b.sponsorId,sponsorName:b.sponsorName,chamber:b.chamber,status:'PASSED',supportFor:b.votesFor,supportAgainst:b.votesAgainst,fiscalCost:b.fiscalCost,policyArea:b.policyArea});}
}

function record(state:GameState,p:Politics4State,type:string,title:string,summary:string,severity:Severity='LOW'){
  p.history.unshift({tick:tick(state),type,title,summary,severity}); p.history=p.history.slice(0,120);
}
function playerName(s:GameState){return `${s.character.firstName} ${s.character.lastName}`;}
function applyWorldPolicy(state:GameState, forecast:BillForecast4, area:string, title:string){
  const country:any=state.world[state.currentCountryIndex];
  if(country){
    country.gdpGrowthRate=num(country.gdpGrowthRate,2.5)+forecast.gdpImpactPct*.08;
    country.unemploymentRate=clamp(num(country.unemploymentRate,5)-forecast.employmentImpact*.015,0,30);
    country.inflationRate=Math.max(0,num(country.inflationRate,2.5)+forecast.inflationImpactPct*.08);
    country.politicalStability=clamp(num(country.politicalStability,65)+forecast.approvalImpact*.05);
  }
  const lw:any=(state as any).livingWorld;
  if(lw?.economy){lw.economy.nationalGdpGrowth=num(lw.economy.nationalGdpGrowth,2.5)+forecast.gdpImpactPct*.06;lw.economy.unemploymentRate=clamp(num(lw.economy.unemploymentRate,5)-forecast.employmentImpact*.01);lw.economy.inflationRate=Math.max(0,num(lw.economy.inflationRate,2.5)+forecast.inflationImpactPct*.05);lw.economy.marketConfidenceIndex=clamp(num(lw.economy.marketConfidenceIndex,70)+forecast.approvalImpact*.12);lw.economy.businessConfidenceIndex=clamp(num(lw.economy.businessConfidenceIndex,70)+forecast.corporateImpact*.08);}
  const bank:any=(state as any).livingBanking; if(bank?.relationshipScores) bank.relationshipScores['government_policy']=clamp(num(bank.relationshipScores['government_policy'],50)+forecast.bankingImpact*.08);
  for(const c of state.companies||[]){
    const sector=(c.industry||'').toLowerCase();
    const exposure=(area==='business'||area==='industry'||area==='tax'||area==='finance')?1:(sector.includes(area.toLowerCase())?1.5:.35);
    c.monthlyNetProfit=num(c.monthlyNetProfit,0)*(1+forecast.corporateImpact*0.0005*exposure);
    c.valuation=Math.max(0,num(c.valuation,0)*(1+forecast.corporateImpact*0.0002*exposure));
  }
  const re:any=(state as any).realEstatePlatform; if(re?.market) re.market.confidence=clamp(num(re.market.confidence,60)+forecast.realEstateImpact*.1);
  recordWorldPlayerAction(state,'POLICY_IMPACT',`${title} enacted: ${area}`,['politics','government','economy','companies','banking','real_estate','npc','social'],Math.min(95,50+Math.round(Math.abs(forecast.gdpImpactPct)*10)));
}

function forecastBill(state:GameState, area:string, cost:number, industries:string[]):BillForecast4{
  const country:any=state.world[state.currentCountryIndex]; const cycle=country?.businessCycle||'Expansion';
  const fiscal=-Math.abs(cost||0); const fiscalBillions=Math.abs(cost||0)/1e9;
  let gdp=area==='infrastructure'?0.45:area==='education'?0.30:area==='health'?0.25:area==='business'?0.35:area==='tax'?-0.25:area==='defence'?0.12:0.05;
  if(cycle==='Recession')gdp*=1.35; if(cycle==='Boom')gdp*=.8;
  const employment=area==='infrastructure'?5.5:area==='housing'?4.5:area==='education'?2.5:area==='health'?2.8:area==='business'?3.2:1.0;
  const inflation=area==='infrastructure'||area==='housing'?0.25:area==='welfare'||area==='health'?0.15:-0.05;
  const corporate=area==='business'?8:area==='tax'?-6:industries.length?3:1;
  const banking=area==='housing'?6:area==='business'?5:area==='tax'?-3:1;
  const realEstate=area==='housing'?10:area==='infrastructure'?5:area==='tax'?-2:1;
  const household=area==='welfare'||area==='health'||area==='education'?7:area==='tax'?-5:2;
  const approval=area==='health'||area==='education'||area==='housing'?4:area==='tax'?-2:1;
  const confidence=clamp(72-(fiscalBillions>5?8:0)-(country?.inflationRate>6?10:0));
  return {gdpImpactPct:gdp,employmentImpact:employment,inflationImpactPct:inflation,fiscalImpact:fiscal,corporateImpact:corporate,bankingImpact:banking,realEstateImpact:realEstate,householdImpact:household,approvalImpact:approval,confidence,narrative:`Estimated ${gdp>=0?'+':''}${gdp.toFixed(2)}% GDP impulse, ${employment.toFixed(1)} employment index points and ${inflation.toFixed(2)}% inflation pressure. Fiscal impact is approximately $${Math.abs(fiscal).toLocaleString()}.`};
}

function blocVote(bloc:VoterBloc4,bill:Bill4,partyId:string){
  const area=bill.policyArea.toLowerCase(); let issue=55;
  for(const [k,w] of Object.entries(bloc.issueWeights)){if(area.includes(k)||bill.title.toLowerCase().includes(k))issue=Math.max(issue,w as number);}
  const affinity=num(bloc.partyAffinity[partyId],50); const effect=num(bill.constituencyEffects[bloc.id],0);
  return clamp(issue*.55+affinity*.25+effect*.2);
}
function politicianVote(a:Politician4,b:Bill4,parties:any[]){
  const fit=ideologyScore(a.ideology,b.policyArea); const constituency=num(b.constituencyEffects[a.constituency],0); const loyalty=a.loyalty*.15; const donor=a.donorDependence>60&&b.policyArea.toLowerCase().includes('business')?8:0; const scandal=a.scandalExposure>70?-8:0;
  const score=fit*.55+constituency*.25+loyalty+donor+scandal+(a.stanceToPlayer*.04);
  return score>=55?'FOR':score<=43?'AGAINST':'ABSTAIN';
}

function allocateSeats4(p:Politics4State, parties:any[], model:ElectoralModel4):Record<string,number>{
  const totals:Record<string,number>={}; for(const party of parties)totals[party.id]=0;
  if(model==='FIRST_PAST_THE_POST'){
    for(const c of p.constituencies){const winner=Object.entries(c.polling).filter(([id])=>parties.some(x=>x.id===id)).sort((a,b)=>num(b[1])-num(a[1]))[0];if(winner)totals[winner[0]]=(totals[winner[0]]||0)+c.seats;}
  } else {
    const votes:Record<string,number>={}; for(const c of p.constituencies)for(const party of parties)votes[party.id]=(votes[party.id]||0)+num(c.polling[party.id],0)*c.population*c.turnout/100;
    const total=Object.values(votes).reduce((a,b)=>a+b,0)||1; const seats=p.constituencies.reduce((a,c)=>a+c.seats,0); const quotas=parties.map(x=>({id:x.id,raw:seats*(votes[x.id]||0)/total,base:Math.floor(seats*(votes[x.id]||0)/total)})); let used=quotas.reduce((a,x)=>a+x.base,0); for(const q of quotas)totals[q.id]=q.base; quotas.sort((a,b)=>(b.raw-b.base)-(a.raw-a.base)); for(let i=used;i<seats;i++){const q=quotas[i%quotas.length];totals[q.id]++;}
    if(model==='MIXED_MEMBER'){ // half district, half proportional top-up
      const district:Record<string,number>={}; for(const c of p.constituencies){const w=Object.entries(c.polling).sort((a,b)=>num(b[1])-num(a[1]))[0];if(w)district[w[0]]=(district[w[0]]||0)+c.seats;} const half=Math.ceil(seats/2); const dEntries=Object.entries(district).sort((a,b)=>b[1]-a[1]); const scaled:Record<string,number>={}; for(const [id,n] of dEntries)scaled[id]=Math.round(n*half/seats); for(const party of parties)totals[party.id]=Math.max(0,Math.round((totals[party.id]+(scaled[party.id]||0))/2));
    }
  }
  return totals;
}

function runAutonomousElection(state:GameState,p:Politics4State,events:any[],news:any[]){
  const t=tick(state); if(t<p.politicalCalendar.nextElectionTick)return; if(p.elections.some(e=>e.electionTick===t))return;
  const parties=(state.politics.parties||[]).slice().sort((a,b)=>b.pollingPercentage-a.pollingPercentage).slice(0,5);
  for(const c of p.constituencies){for(const party of parties){const base=num(c.polling[party.id],party.pollingPercentage);const localPressure=num(p.constituencyPressure[c.name],50);c.polling[party.id]=clamp(base+(party.pollingPercentage-base)*.15+(localPressure-50)*.03+(Math.random()-.5)*1.2);}}
  const candidates=parties.map((party:any)=>{const actor=p.politicians.find(x=>x.partyId===party.id);return {id:actor?.id||`party_candidate_${party.id}`,name:actor?.name||party.partyLeader,partyId:party.id,support:0,resources:num(party.partyFunds,0),scandal:actor?.scandalExposure||15};});
  const election:Election4={id:`auto_election_${t}`,office:state.politics.currentOffice.title==='Citizen'?'Member of Parliament':state.politics.currentOffice.title,jurisdiction:state.politics.currentOffice.cityOrNation,status:'VOTING',startedTick:t-6,electionTick:t,candidates,blocResults:{},turnout:0};
  let weightedTurnout=0; for(const b of p.voterBlocs){const raw=election.candidates.map(c=>{const partyBoost=num(b.partyAffinity[c.partyId],45);const actor=p.politicians.find(a=>a.id===c.id);const competence=actor?actor.competence*.12:5;const reputation=actor?actor.reputation*.15:10;const scandal=-(actor?.scandalExposure||c.scandal)*.08;return {id:c.id,score:Math.max(1,partyBoost*.55+competence+reputation+scandal+(Math.random()*5-2.5))};});const total=raw.reduce((a,x)=>a+x.score,0);const results:Record<string,number>={};for(const r of raw)results[r.id]=r.score/total*100;election.blocResults[b.id]=results;weightedTurnout+=b.turnout*b.weight;for(const c of election.candidates)c.support+=results[c.id]*b.weight/100;}
  election.turnout=clamp(weightedTurnout/100);
  const seatTotals=allocateSeats4(p,parties,p.electoralModel); (p as any).derivedSeatTotals=seatTotals;
  for(const c of election.candidates)c.support=clamp(c.support);
  const partyWinner=Object.entries(seatTotals).sort((a,b)=>b[1]-a[1])[0]; const winner=election.candidates.find(c=>c.partyId===partyWinner?.[0])||election.candidates.slice().sort((a,b)=>b.support-a.support)[0]; const runner=election.candidates.slice().sort((a,b)=>b.support-a.support)[1]; election.winnerId=winner.id;election.margin=Math.max(0,winner.support-(runner?.support||0));election.status='CERTIFIED';p.elections.unshift(election);p.politicalCalendar.lastElectionTick=t;p.politicalCalendar.nextElectionTick=t+48;
  const majorityNeeded=Math.floor(p.constituencies.reduce((a,c)=>a+c.seats,0)/2)+1; const winnerSeats=seatTotals[winner.partyId]||0; const coalitionCandidates=Object.entries(seatTotals).sort((a,b)=>b[1]-a[1]); let governmentParties=[winner.partyId]; let seats=winnerSeats; for(const [id,n] of coalitionCandidates){if(seats>=majorityNeeded)break;if(id!==winner.partyId){governmentParties.push(id);seats+=n;}}
  const gov:Government4={id:`gov4_election_${t}`,title:`${governmentParties.length>1?'Coalition':'Majority'} Government`,leaderId:winner.id,parties:governmentParties,seats,majorityNeeded,stability:clamp(52+winner.support*.3-(governmentParties.length-1)*4),approval:clamp(p.publicOpinion.government+(winner.support-50)*.15),formedTick:t,status:seats>=majorityNeeded?'ACTIVE':'MINORITY',coalitionAgreement:governmentParties.slice(1).map(id=>`Portfolio and policy concessions for ${state.politics.parties.find(x=>x.id===id)?.name||id}`),cabinet:[],confidenceVotes:0,survivedConfidenceVotes:0};p.governments.unshift(gov);p.currentGovernmentId=gov.id;
  if(winner.id===state.character.id){state.politics.currentOffice.inOffice=true;state.politics.currentOffice.termMonthsRemaining=48;state.politics.currentOffice.approvalRating=clamp(winner.support);state.character.attributes.worldInfluence=clamp(state.character.attributes.worldInfluence+4);}
  const narrative=`Election used ${p.electoralModel.replaceAll('_',' ').toLowerCase()} with district polling, voter blocs, turnout, candidate competence, reputation and scandal. ${winner.name} led with ${winner.support.toFixed(1)}% weighted support; the governing bloc secured ${seats}/${majorityNeeded} seats.`;
  events.push({id:`ev_auto_election_${t}`,timestampMonth:state.currentMonth,timestampYear:state.currentYear,age:state.character.age,category:'Politics',title:`Election Certified: ${winner.name}`,description:narrative,consequences:{worldInfluenceChange:winner.id===state.character.id?4:0}}); news.push({id:`news_auto_election_${t}`,month:state.currentMonth,year:state.currentYear,headline:`Election certified: ${winner.name} wins`,body:narrative,category:'Politics',importance:'MAJOR',severity:'Normal',impactExplanation:'District seat allocation and individual voter behaviour determined the result.'});
}

export function performPolitics4Action(state:GameState,action:Politics4Action,payload:any={}):{success:boolean;message:string}{
  const p=ensurePolitics4(state), t=tick(state), key=action;
  if(['CONSTITUENCY_MEET','POLITICAL_DONOR_MEETING','CAMPAIGN_RALLY','CAMPAIGN_MEDIA','CAMPAIGN_DEBATE','CAMPAIGN_VOTER_OUTREACH','CALL_CONFIDENCE'].includes(action) && p.monthlyActions[key]===t)return {success:false,message:'This political action has already been used this month.'};
  let message='Political action completed.';
  if(action==='LEGISLATURE_INTRODUCE'){
    if(!state.politics.currentOffice.inOffice)return {success:false,message:'You must hold public office to introduce legislation.'};
    const area=payload.policyArea||'business'; const title=payload.title||'National Development and Public Services Bill'; const cost=Math.max(0,num(payload.fiscalCost,0));
    const forecast=forecastBill(state,area,cost,payload.industries||[]); const bill:Bill4={id:`p4_bill_${t}_${Date.now()}`,title,sponsorId:state.character.id,sponsorName:playerName(state),chamber:'PARLIAMENT',status:'COMMITTEE',policyArea:area,fiscalCost:cost,support:50,opposition:30,amendments:0,affectedIndustries:payload.industries||[],constituencyEffects:payload.constituencyEffects||{},forecast,votesFor:0,votesAgainst:0,introducedTick:t};
    p.bills.unshift(bill); message=`Introduced ${title}. Forecast: ${forecast.narrative}`;
  } else if(action==='LEGISLATURE_AMEND'){
    const b=p.bills.find(x=>x.id===payload.billId); if(!b)return {success:false,message:'Bill not found.'}; b.amendments++; b.support=clamp(b.support+3); b.opposition=clamp(b.opposition-1); if(payload.area)b.policyArea=payload.area; p.amendments.unshift({id:`amend_${t}_${Date.now()}`,billId:b.id,sponsorId:state.character.id,text:payload.text||'Committee amendment',fiscalDelta:num(payload.fiscalDelta,0),supportEffect:num(payload.supportEffect,3),status:'ACCEPTED'}); message=`Amended ${b.title}; amendment ${b.amendments} accepted and entered into the legislative record.`;
  } else if(action==='LEGISLATURE_HEARING'){
    const b=p.bills.find(x=>x.id===payload.billId); if(!b)return {success:false,message:'Bill not found.'}; b.status='DEBATE'; b.support=clamp(b.support+2); message=`Committee hearing held on ${b.title}; evidence and stakeholder testimony entered the legislative record.`;
  } else if(action==='LEGISLATURE_VOTE'){
    const b=p.bills.find(x=>x.id===payload.billId); if(!b)return {success:false,message:'Bill not found.'};
    let forVotes=0,againstVotes=0; const whip=p.whips.find(w=>w.partyId===b.sponsorId)||p.whips.find(w=>w.partyId===state.politics.selectedPartyId); for(const a of p.politicians){let v: 'FOR'|'AGAINST'|'ABSTAIN'=politicianVote(a,b,state.politics.parties); const w=p.whips.find(x=>x.partyId===a.partyId); if(w?.targetBillId===b.id&&w.instruction!=='FREE'){const rebelRoll=Math.random()*100; if(rebelRoll>w.strength)v=w.instruction==='FOR'?'AGAINST':'FOR';else v=w.instruction;} if(v==='FOR')forVotes++;else if(v==='AGAINST')againstVotes++;a.votingRecord.unshift({billId:b.id,vote:v,tick:t});a.votingRecord=a.votingRecord.slice(0,80);}
    const amendmentEffect=p.amendments.filter(a=>a.billId===b.id&&a.status==='ACCEPTED').reduce((s,a)=>s+a.supportEffect,0); const lobbyEffect=p.lobbyingPressure.filter(x=>x.billId===b.id).reduce((s,x)=>s+(x.position==='SUPPORT'?x.influence:-x.influence)*.03,0); b.support=clamp(b.support+amendmentEffect*.05+lobbyEffect); const blocSupport=p.voterBlocs.reduce((sum,v)=>sum+blocVote(v,b,b.sponsorId),0)/p.voterBlocs.length; forVotes+=Math.round(blocSupport/20); againstVotes+=Math.round((100-blocSupport)/20); b.votesFor=forVotes;b.votesAgainst=againstVotes;b.status=forVotes>againstVotes?'PASSED':'FAILED'; if(b.status==='PASSED'){b.enactedTick=t;applyWorldPolicy(state,b.forecast,b.policyArea,b.title);p.publicOpinion.government=clamp(p.publicOpinion.government+b.forecast.approvalImpact);} message=`${b.title} ${b.status==='PASSED'?'passed':'failed'} ${forVotes}-${againstVotes}. ${b.forecast.narrative}`;
  } else if(action==='CONSTITUENCY_MEET'){
    const constituency=payload.constituency||'Central District'; p.constituencyPressure[constituency]=clamp(num(p.constituencyPressure[constituency],50)+6); p.publicOpinion.services=clamp(p.publicOpinion.services+2);p.monthlyActions[key]=t;message=`Held a constituency meeting in ${constituency}; local concerns have been added to your political agenda.`;
  } else if(action==='PARTY_WHIP'){
    for(const a of p.politicians.filter(x=>x.partyId===state.politics.selectedPartyId))a.loyalty=clamp(a.loyalty+5); p.publicOpinion.government=clamp(p.publicOpinion.government+1);message='Party leadership coordinated a caucus position; loyalty and voting discipline changed.';
  } else if(action==='NEGOTIATE_COALITION' || action==='FORMATION_NEGOTIATE'){
    const partners=(payload.parties||[state.politics.selectedPartyId,'party_centrist']).filter(Boolean); const seats=Math.round(partners.reduce((s:string[],id:string)=>s.concat([id]),[]).length*20+p.publicOpinion.government*.3); const gov:Government4={id:`gov4_${t}_${Date.now()}`,title:payload.title||'Coalition Government',leaderId:state.character.id,parties:partners,seats,majorityNeeded:Math.max(51,Math.round(payload.majorityNeeded||51)),stability:clamp(55+p.publicOpinion.government*.25),approval:clamp(p.publicOpinion.government),formedTick:t,status:'ACTIVE',coalitionAgreement:payload.concessions||[],cabinet:[],confidenceVotes:0,survivedConfidenceVotes:0};p.governments.unshift(gov);p.currentGovernmentId=gov.id;message=`Coalition negotiations produced a ${gov.seats>=gov.majorityNeeded?'majority':'minority'} government with ${partners.join(', ')}.`;
  } else if(action==='CALL_CONFIDENCE'){
    const g=p.governments.find(x=>x.id===p.currentGovernmentId);if(!g)return{success:false,message:'No active government exists.'}; const pass=g.stability+g.approval+(p.publicOpinion.government||0)>100;g.confidenceVotes++;p.monthlyActions[key]=t;if(pass){g.survivedConfidenceVotes++;g.stability=clamp(g.stability+3);message='Government survived the confidence vote.';}else{g.stability=clamp(g.stability-15);g.status='COLLAPSED';p.currentGovernmentId=null;message='Government lost the confidence vote and collapsed into a political crisis.';}
  } else if(action==='APPOINT_CABINET'){
    const g=p.governments.find(x=>x.id===p.currentGovernmentId);if(!g)return{success:false,message:'No active government.'}; const politician=p.politicians.find(x=>x.id===payload.politicianId);if(!politician)return{success:false,message:'Politician not found.'};g.cabinet.push({office:payload.office||'Minister',politicianId:politician.id,competence:politician.competence,loyalty:politician.loyalty});message=`Appointed ${politician.name} as ${payload.office||'Minister'}.`;
  } else if(action==='SET_BUDGET_PRIORITY'){
    const area=payload.area||'infrastructure'; const delta=num(payload.delta,5); p.policyEffects[`budget:${area}`]=num(p.policyEffects[`budget:${area}`],0)+delta; const gov:any=(state as any).governmentLiving;if(gov?.budget?.departmentAllocations){gov.budget.departmentAllocations[area]=(gov.budget.departmentAllocations[area]||0)+delta*1000000;}message=`Shifted government budget priority toward ${area}.`;
  } else if(action==='DECLARE_CONFLICT'){p.publicOpinion.integrity=clamp(p.publicOpinion.integrity+4);message='Declared a conflict of interest and placed the affected decision under formal scrutiny.';}
  else if(action==='RECUSE'){p.publicOpinion.integrity=clamp(p.publicOpinion.integrity+3);message='Recused yourself from the affected political decision.';}
  else if(action==='CAMPAIGN_STRATEGY'){p.publicOpinion.government=clamp(p.publicOpinion.government+2);message=`Campaign strategy adopted: ${payload.strategy||'Jobs and prosperity'}.`;
  } else if(action==='CAMPAIGN_FUNDRAISE'){const amount=Math.max(0,num(payload.amount,25000));if(state.finances.cash<amount)return{success:false,message:'Insufficient personal cash for this campaign contribution.'};state.finances.cash-=amount;const donor=p.donors.find(d=>d.id===payload.donorId)||p.donors[0];p.publicOpinion.integrity=clamp(p.publicOpinion.integrity-(donor?.compliance||90)<80?1:0);message=`Raised $${amount.toLocaleString()} for the campaign through ${donor?.name||'supporters'}.`;
  } else if(action==='CAMPAIGN_RALLY'){p.publicOpinion.government=clamp(p.publicOpinion.government+4);p.monthlyActions[key]=t;message='Held a campaign rally; turnout, volunteer energy and local visibility increased.';}
  else if(action==='CAMPAIGN_DEBATE'){const intellect=num(state.character.attributes.intelligence,50);p.publicOpinion.government=clamp(p.publicOpinion.government+(intellect-50)/10);p.monthlyActions[key]=t;message='Completed a public debate; voter assessments shifted based on policy knowledge and communication.';}
  else if(action==='CAMPAIGN_MEDIA'){p.publicOpinion.government=clamp(p.publicOpinion.government+2);p.monthlyActions[key]=t;message='Ran a media programme across news and social channels.';}
  else if(action==='CAMPAIGN_VOTER_OUTREACH'){const b=p.voterBlocs.find(x=>x.id===payload.blocId)||p.voterBlocs[0];b.trust=clamp(b.trust+6);p.monthlyActions[key]=t;message=`Conducted targeted voter outreach with ${b.name}.`;
  } else if(action==='ELECTION_HOLD'){
    const election:Election4={id:`e4_${t}_${Date.now()}`,office:payload.office||state.politics.currentOffice.title,jurisdiction:payload.jurisdiction||state.politics.currentOffice.cityOrNation,status:'VOTING',startedTick:t,electionTick:t,candidates:[{id:state.character.id,name:playerName(state),partyId:state.politics.selectedPartyId||'independent',support:clamp(p.publicOpinion.government),resources:100,scandal:0}],blocResults:{},turnout:0};
    let total=0; for(const b of p.voterBlocs){const support=clamp(blocVote(b,{id:election.id,title:'Campaign',sponsorId:state.character.id,sponsorName:playerName(state),chamber:'PARLIAMENT',status:'VOTING',policyArea:'public services',fiscalCost:0,support:0,opposition:0,amendments:0,affectedIndustries:[],constituencyEffects:{},forecast:forecastBill(state,'public services',0,[]),votesFor:0,votesAgainst:0,introducedTick:t},state.politics.selectedPartyId||'independent'));election.blocResults[b.id]={[state.character.id]:support};total+=support*b.weight;}
    election.turnout=clamp(p.voterBlocs.reduce((s,b)=>s+b.turnout*b.weight,0)/100); const support=clamp(total/100);election.candidates[0].support=support;election.winnerId=support>=50?state.character.id:undefined;election.margin=Math.abs(support-50);election.status='CERTIFIED';p.elections.unshift(election);p.politicalCalendar.lastElectionTick=t;p.politicalCalendar.nextElectionTick=t+48;
    if(election.winnerId){state.politics.currentOffice.inOffice=true;state.politics.currentOffice.termMonthsRemaining=48;state.politics.currentOffice.approvalRating=clamp(support);state.character.attributes.worldInfluence=clamp(state.character.attributes.worldInfluence+5);message=`Election certified: ${playerName(state)} won ${election.office} with ${support.toFixed(1)}% weighted voter support.`;}else{message=`Election certified: campaign received ${support.toFixed(1)}% weighted voter support and did not secure the office.`;}
  } else if(action==='POLITICAL_DONOR_MEETING'){p.publicOpinion.integrity=clamp(p.publicOpinion.integrity+1);p.monthlyActions[key]=t;message='Met political donors and recorded campaign-finance commitments for compliance review.';}
  else if(action==='MEDIA_RESPONSE'){p.publicOpinion.government=clamp(p.publicOpinion.government+(payload.success?2:-2));message='Issued a public response to the political story and updated the media environment.';}
  else if(action==='DIPLOMATIC_NEGOTIATION'){p.publicOpinion.government=clamp(p.publicOpinion.government+1);message='Negotiated with an international counterpart; diplomatic confidence improved.';}
  else if(action==='ASSIGN_COMMITTEE'){
    const c=p.committees.find(x=>x.id===payload.committeeId)||p.committees[0]; const a=p.politicians.find(x=>x.id===payload.politicianId)||p.politicians[0]; if(!c||!a)return{success:false,message:'Committee or politician not found.'}; if(!c.memberIds.includes(a.id))c.memberIds.push(a.id); if(payload.chair)c.chairId=a.id; c.workload=clamp(c.workload+2); message=`Assigned ${a.name} to ${c.name}${payload.chair?' as chair':''}.`;
  } else if(action==='SET_WHIP'){
    const w=p.whips.find(x=>x.partyId===(payload.partyId||state.politics.selectedPartyId))||p.whips[0]; if(!w)return{success:false,message:'No party whip available.'}; w.instruction=payload.instruction||'FOR'; w.targetBillId=payload.billId; w.strength=clamp(num(payload.strength,70)); w.rebels=Math.max(0,Math.round((100-w.strength)/4)); message=`Parliamentary whip set to ${w.instruction} with ${Math.round(w.strength)}% discipline.`;
  } else if(action==='SHADOW_APPOINT'){
    const a=p.politicians.find(x=>x.id===payload.politicianId)||p.politicians[0]; if(!a)return{success:false,message:'Politician not found.'}; const existing=p.shadowCabinet.find(x=>x.office===payload.office); const row={office:payload.office||'Finance',politicianId:a.id,competence:a.competence,attackFocus:payload.attackFocus||'government performance',approval:50}; if(existing)Object.assign(existing,row);else p.shadowCabinet.push(row); message=`${a.name} appointed to the opposition shadow cabinet as ${row.office}.`;
  } else if(action==='BILL_VOTE_TRADE'){
    const b=p.bills.find(x=>x.id===payload.billId); const from=p.politicians.find(x=>x.id===payload.fromPoliticianId)||p.politicians[0]; const to=p.politicians.find(x=>x.id===payload.toPoliticianId)||p.politicians[1]; if(!b||!from||!to)return{success:false,message:'Bill or politician not found.'}; const accepted=(to.reputation+to.loyalty)/2>45; p.voteTrades.unshift({id:`trade_${t}_${Date.now()}`,billId:b.id,fromPoliticianId:from.id,toPoliticianId:to.id,offeredBillId:payload.offeredBillId,concession:payload.concession||'Committee support',accepted}); if(accepted)to.stanceToPlayer+=5; message=accepted?`${to.name} accepted a vote-trade concession on ${b.title}.`:`${to.name} rejected the proposed vote trade.`;
  } else if(action==='LOBBY_BILL'){
    const b=p.bills.find(x=>x.id===payload.billId); if(!b)return{success:false,message:'Bill not found.'}; const pressure:LobbyingPressure4={id:`lobby_${t}_${Date.now()}`,billId:b.id,organization:payload.organization||'Industry Association',influence:clamp(num(payload.influence,35)),position:payload.position||'SUPPORT',spending:Math.max(0,num(payload.spending,100000)),compliance:clamp(num(payload.compliance,90)),disclosed:payload.disclosed!==false}; p.lobbyingPressure.unshift(pressure); if(pressure.position==='SUPPORT')b.support=clamp(b.support+pressure.influence*.06);else b.opposition=clamp(b.opposition+pressure.influence*.06); message=`Lobbying pressure recorded on ${b.title}; ${pressure.organization} is ${pressure.position.toLowerCase()}.`;
  } else if(action==='DISTRICT_POLL'){
    const c=p.constituencies.find(x=>x.id===payload.constituencyId)||p.constituencies[0]; if(!c)return{success:false,message:'Constituency not found.'}; const partyId=payload.partyId||state.politics.selectedPartyId||'independent'; const base=num(c.polling[partyId],num(state.politics.parties.find(x=>x.id===partyId)?.pollingPercentage,25)); c.polling[partyId]=clamp(base+(num(p.publicOpinion.government,50)-50)*.08+(Math.random()*4-2)); c.margin=Math.abs(c.polling[partyId]-(Object.entries(c.polling).filter(([id])=>id!==partyId).map(([,v])=>num(v)).sort((a,b)=>b-a)[0]||0)); message=`District polling updated for ${c.name}: ${partyId} at ${c.polling[partyId].toFixed(1)}%.`;
  } else if(action==='SET_ELECTORAL_MODEL'){
    p.electoralModel=payload.model||'FIRST_PAST_THE_POST'; message=`Electoral model set to ${p.electoralModel.replaceAll('_',' ').toLowerCase()}. Future elections will use district-seat allocation under this model.`;
  } else if(action==='RESHUFFLE_CABINET'){
    const g=p.governments.find(x=>x.id===p.currentGovernmentId); const a=p.politicians.find(x=>x.id===payload.politicianId)||p.politicians[0]; if(!g||!a)return{success:false,message:'Active government or politician not found.'}; const office=payload.office||'Minister'; const existing=g.cabinet.find(x=>x.office===office); if(existing){p.cabinetReshuffles.unshift({id:`reshuffle_${t}_${Date.now()}`,tick:t,removedPoliticianId:existing.politicianId,appointedPoliticianId:a.id,office,reason:payload.reason||'Performance and coalition management'});existing.politicianId=a.id;existing.competence=a.competence;existing.loyalty=a.loyalty;}else g.cabinet.push({office,politicianId:a.id,competence:a.competence,loyalty:a.loyalty}); message=`Cabinet reshuffle appointed ${a.name} as ${office}.`;
  } else if(action==='NOMINATE_SUCCESSOR'){
    const a=p.politicians.find(x=>x.id===payload.candidateId)||p.politicians[0]; if(!a)return{success:false,message:'Successor candidate not found.'}; const support=clamp((a.loyalty+a.influenceScore+a.reputation)/3); const row:Succession4={id:`succ_${t}_${Date.now()}`,office:payload.office||state.politics.currentOffice.title,candidateId:a.id,support,readiness:clamp(a.competence*.7+a.attendance*.3),loyalty:a.loyalty,status:support>70?'FRONTRUNNER':'EMERGING'}; p.succession.unshift(row); message=`${a.name} entered the succession process for ${row.office}.`;
  } else if(action==='TRIGGER_CONSTITUTIONAL_CRISIS'){
    const crisis:ConstitutionalCrisis4={id:`cc_${t}_${Date.now()}`,type:payload.type||'Executive-Legislative Conflict',trigger:payload.trigger||'Institutional deadlock',severity:clamp(num(payload.severity,65)),legitimacy:clamp(100-num(payload.severity,65)),institutionalActors:payload.actors||['Executive','Legislature','Judiciary'],status:'OPEN'}; p.constitutionalCrises.unshift(crisis); const country:any=state.world[state.currentCountryIndex]; if(country)country.politicalStability=clamp(num(country.politicalStability,65)-crisis.severity*.05); message=`Constitutional crisis opened: ${crisis.type}. Institutional legitimacy is under pressure.`;
  } else if(action==='RESOLVE_CONSTITUTIONAL_CRISIS'){
    const c=p.constitutionalCrises.find(x=>x.id===payload.crisisId)||p.constitutionalCrises.find(x=>x.status!=='RESOLVED'); if(!c)return{success:false,message:'No open constitutional crisis found.'}; c.status='RESOLVED'; c.resolution=payload.resolution||'Institutional compromise and judicially compliant settlement'; c.legitimacy=clamp(c.legitimacy+20); p.publicOpinion.integrity=clamp(p.publicOpinion.integrity+3); message=`Constitutional crisis resolved through ${c.resolution}.`;
  } else if(action==='CONSTITUENCY_CASEWORK'){
    const c=p.constituencies.find(x=>x.id===payload.constituencyId)||p.constituencies[0]; if(!c)return{success:false,message:'Constituency not found.'}; const issue=payload.issue||'jobs'; c.issues[issue]=clamp(num(c.issues[issue],50)+5); c.polling[state.politics.selectedPartyId||'independent']=clamp(num(c.polling[state.politics.selectedPartyId||'independent'],25)+2); message=`Constituency casework focused on ${issue} in ${c.name}; local support adjusted.`;
  }
  record(state,p,action,message,message,action.includes('VOTE')||action.includes('ELECTION')?'HIGH':'LOW');
  recordWorldPlayerAction(state,`POLITICS4_${action}`,message,['politics','government','economy','companies','banking','real_estate','npc','social'],70);
  return {success:true,message};
}

export function advancePolitics4(state:GameState,events:any[]=[],news:any[]=[]){
  const p=ensurePolitics4(state),t=tick(state);if(p.lastTick===t)return;p.lastTick=t;
  // Keep the unified layer synchronized with legacy government/party systems.
  const gov:any=(state as any).governmentLiving; const adv:any=state.politics.advanced;
  if(gov?.parliamentarians?.length){
    for(const m of gov.parliamentarians){if(!p.politicians.some(x=>x.id===m.id))p.politicians.push({id:m.id,name:m.name,partyId:m.partyId,factionId:'',constituency:m.constituency,ideology:m.ideology,ambition:55,influenceScore:num(m.influence,50),loyalty:num(m.loyalty,55),donorDependence:30,scandalExposure:20,reputation:55,attendance:num(m.attendance,80),competence:65,incumbency:60,policyPreferences:{},constituencyInterests:['jobs','public services'],votingRecord:[],donorIds:[],stanceToPlayer:0});}
  }
  for(const a of p.politicians){a.ambition=clamp(a.ambition+(Math.random()-.48)*2);a.reputation=clamp(a.reputation+(p.publicOpinion.government-50)*.01);a.scandalExposure=clamp(a.scandalExposure+(Math.random()<.03?5:-.3));if(a.ambition>85&&a.stanceToPlayer<10)a.stanceToPlayer-=1;}
  // Existing political parties remain authoritative; their polling now responds to individual voter blocs and the economy.
  for(const party of state.politics.parties){const affinity=p.voterBlocs.reduce((s,b)=>s+num(b.partyAffinity[party.id],50)*b.weight,0)/100;const economic=(state.world[state.currentCountryIndex]?.businessCycle==='Recession'?-2:1);party.pollingPercentage=clamp(num(party.pollingPercentage,25)+(affinity-50)*.015+economic*.1+(Math.random()-.5)*.35);}
  // Bills receive constituency and economic pressure between sessions.
  for(const b of p.bills.filter(x=>x.status==='COMMITTEE'||x.status==='DEBATE')){const econ=state.world[state.currentCountryIndex]?.businessCycle==='Recession'?-1:0.5;b.support=clamp(b.support+econ+(b.forecast.approvalImpact*.03));b.opposition=clamp(b.opposition-econ*.2);if(b.support>b.opposition+15)b.status='DEBATE';}
  // Government stability is endogenous: approval, parliamentary cohesion, economy and scandals matter.
  const g=p.governments.find(x=>x.id===p.currentGovernmentId);if(g){const economy=state.world[state.currentCountryIndex]?.businessCycle==='Recession'?-3:state.world[state.currentCountryIndex]?.businessCycle==='Boom'?2:0;const scandal=(adv?.scandals||[]).reduce((s:number,x:any)=>s+num(x.severity,0)*.02,0);g.approval=clamp((p.publicOpinion.government+p.publicOpinion.services+p.publicOpinion.integrity)/3);g.stability=clamp(g.stability+(g.approval-50)*.04+economy-scandal);if(g.stability<25){g.status='COLLAPSED';p.currentGovernmentId=null;events.push({id:`ev_gov_collapse_${t}`,timestampMonth:state.currentMonth,timestampYear:state.currentYear,age:state.character.age,category:'Politics',title:'Government Coalition Collapses',description:`The governing coalition has lost stability after sustained political and economic pressure. A caretaker period and formation negotiations begin.`,consequences:{reputationChange:-2,worldInfluenceChange:1}});news.push({id:`news_gov_collapse_${t}`,month:state.currentMonth,year:state.currentYear,headline:'Government coalition collapses',body:'Parliamentary arithmetic, public approval and economic conditions forced a change in government.',category:'Politics',importance:'MAJOR',severity:'Warning',impactExplanation:'Political stability has deteriorated.'});}}
  // Government living system receives the same enacted bills without duplicating them.
  if(gov?.bills){for(const b of p.bills.filter(x=>x.status==='PASSED')){if(!gov.bills.some((x:any)=>x.title===b.title)){gov.bills.unshift({id:b.id,title:b.title,sponsorNpcId:state.character.id,sponsorName:playerName(state),chamber:'PARLIAMENT',status:'PASSED',supportFor:b.votesFor,supportAgainst:b.votesAgainst,fiscalCost:b.fiscalCost,policyArea:b.policyArea});}}}
  // Election pressure builds from individual voter blocs rather than a single polling number.
  const electionDue=t>=p.politicalCalendar.nextElectionTick; if(electionDue && state.politics.currentOffice.inOffice){p.publicOpinion.government=clamp(p.publicOpinion.government+(state.politics.currentOffice.approvalRating-50)*.03);}
  runAutonomousElection(state,p,events,news);
  // Politics 4.1 autonomous institutional dynamics: districts, whips, cabinet and succession.
  for(const c of p.constituencies){
    const pressure=num(p.constituencyPressure[c.name],50); c.turnout=clamp(c.turnout+(pressure-50)*.01); for(const party of state.politics.parties||[]){const base=num(c.polling[party.id],party.pollingPercentage); c.polling[party.id]=clamp(base+(party.pollingPercentage-base)*.08+(p.publicOpinion.government-50)*.015+(Math.random()-.5)*.25);}
  }
  for(const w of p.whips){w.rebels=Math.max(0,Math.round((100-w.strength)/4)); if(w.targetBillId&&w.instruction!=='FREE')w.strength=clamp(w.strength+(Math.random()-.45));}
  for(const sc of p.succession){const a=p.politicians.find(x=>x.id===sc.candidateId); if(a){sc.readiness=clamp(sc.readiness+(a.reputation-50)*.02);sc.support=clamp(sc.support+(a.influenceScore-50)*.015);if(sc.support>75)sc.status='FRONTRUNNER';}}
  for(const crisis of p.constitutionalCrises.filter(x=>x.status!=='RESOLVED')){crisis.severity=clamp(crisis.severity+(p.publicOpinion.government<40?1.5:-.8));crisis.legitimacy=clamp(crisis.legitimacy+(p.publicOpinion.integrity-50)*.02);if(crisis.severity>85){crisis.status='ESCALATED';events.push({id:`ev_const_crisis_${crisis.id}`,timestampMonth:state.currentMonth,timestampYear:state.currentYear,age:state.character.age,category:'Politics',title:'Constitutional Crisis Escalates',description:`${crisis.type} has escalated as institutional legitimacy and political stability deteriorate.`,consequences:{reputationChange:-2,worldInfluenceChange:1}});}}
  const g4=p.governments.find(x=>x.id===p.currentGovernmentId); if(g4&&g4.status!=='COLLAPSED'){for(const cab of g4.cabinet){const a=p.politicians.find(x=>x.id===cab.politicianId);if(a){cab.competence=a.competence;cab.loyalty=a.loyalty;}}}
  // District-seat arithmetic is retained as a derived electoral layer for future and autonomous elections.
  const seatTotals:Record<string,number>={}; for(const c of p.constituencies){const entries=Object.entries(c.polling).sort((a,b)=>num(b[1])-num(a[1])); if(entries.length)seatTotals[entries[0][0]]=(seatTotals[entries[0][0]]||0)+c.seats;}
  (p as any).derivedSeatTotals=seatTotals;
  p.history=p.history.slice(0,120);
}
