import { GameState, PoliticalActor, PoliticalFaction, PoliticalParty } from '../types';
import { recordWorldPlayerAction } from './worldGovernorCoordinator';
import { advancePolitics4, ensurePolitics4 } from './politics4Engine';

type PoliticalAction =
  | 'BUILD_CAPITAL' | 'NEGOTIATE' | 'INTRODUCE_BILL' | 'AMEND_BILL' | 'VOTE_BILL'
  | 'CALL_HEARING' | 'APPOINT_MINISTER' | 'FORM_COALITION' | 'HOLD_RALLY'
  | 'PRESS_CONFERENCE' | 'MEET_DONORS' | 'POLLING' | 'CAMPAIGN_DEBATE'
  | 'RELEASE_POLICY' | 'RESPOND_SCANDAL' | 'CHALLENGE_LEADER' | 'RESIGN'
  | 'DECLARE_INTEREST' | 'RECUSE' | 'DIPLOMATIC_MISSION' | 'NEGOTIATE_TREATY' | 'LAUNCH_CAMPAIGN';

export interface PoliticalBill { id:string; title:string; sponsor:string; status:'DRAFT'|'COMMITTEE'|'DEBATE'|'VOTE'|'PASSED'|'FAILED'; support:number; opposition:number; amendments:number; fiscalCost:number; affectedIndustries:string[]; }
export interface PoliticalCampaign { id:string; office:string; stage:'SELECTION'|'FUNDRAISING'|'MEDIA'|'POLLING'|'DEBATE'|'ELECTION'; budget:number; support:number; momentum:number; volunteers:number; endorsements:number; scandalRisk:number; }
export interface Coalition { id:string; partners:string[]; seats:number; stability:number; concessions:string[]; }
export interface PoliticalScandal { id:string; title:string; severity:number; exposure:number; status:'RUMOUR'|'INVESTIGATING'|'PUBLIC'|'CLEARED'; }
export interface PoliticalCabinet { ministry:string; minister:string; approval:number; performance:number; }
export interface AdvancedPoliticalSystem {
  version:3; politicalCapital:number; grassrootsSupport:number; donorSupport:number; mediaInfluence:number; institutionalInfluence:number; eliteSupport:number; publicTrust:number;
  parties: Array<PoliticalParty & {membership:number; internalStability:number; factions:string[]}>;
  actors: PoliticalActor[]; factions: PoliticalFaction[]; bills: PoliticalBill[]; campaigns: PoliticalCampaign[]; coalitions: Coalition[]; cabinet: PoliticalCabinet[];
  scandals: PoliticalScandal[]; polling:number; governmentStability:number; legislativeApproval:number; oppositionStrength:number;
  budget:{revenue:number; expenditure:number; deficit:number; priorities:Record<string,number>}; diplomaticStanding:number;
  lastMonthlyTick:number; actionCooldowns:Record<string,number>; history:Array<{tick:number;action:PoliticalAction;summary:string;impact:string}>;
}

const ensure = (state:GameState):AdvancedPoliticalSystem => {
  const p:any = state.politics;
  if (!p.advanced) {
    const partyRows = p.parties.map((x:any)=>({...x,membership:10000,internalStability:70,factions:[]}));
    p.advanced = {
      version:3, politicalCapital:p.currentOffice.politicalCapital||10, grassrootsSupport:25, donorSupport:10, mediaInfluence:10, institutionalInfluence:5, eliteSupport:5, publicTrust:50,
      parties:partyRows, actors:[], factions:[], bills:[], campaigns:[], coalitions:[], cabinet:[], scandals:[], polling:p.currentOffice.approvalRating||50, governmentStability:70, legislativeApproval:50, oppositionStrength:35,
      budget:{revenue:0,expenditure:0,deficit:0,priorities:{health:20,education:20,infrastructure:20,defence:10,justice:10}}, diplomaticStanding:50,lastMonthlyTick:-1,actionCooldowns:{},history:[]
    };
  }
  return p.advanced as AdvancedPoliticalSystem;
};

const clamp=(n:number,a=0,b=100)=>Math.max(a,Math.min(b,n));
const cooldown=(p:AdvancedPoliticalSystem,key:string,tick:number)=>p.actionCooldowns[key]===tick;
const setCooldown=(p:AdvancedPoliticalSystem,key:string,tick:number)=>{p.actionCooldowns[key]=tick;};

export function performPoliticalAction(state:GameState, action:PoliticalAction, payload:any={}): {success:boolean;message:string} {
  const p=ensure(state), tick=state.simulationTick;
  if (['HOLD_RALLY','PRESS_CONFERENCE','MEET_DONORS','POLLING','CAMPAIGN_DEBATE','BUILD_CAPITAL'].includes(action) && cooldown(p,action,tick)) return {success:false,message:'This political action has already been used this month.'};
  let msg='Political action completed.';
  switch(action){
    case 'LAUNCH_CAMPAIGN': {
      const budget=Math.max(0,Number(payload.budget||0));
      if (budget>state.finances.cash) return {success:false,message:'Insufficient cash for this campaign.'};
      state.finances.cash-=budget;
      p.campaigns.unshift({id:`camp_${tick}_${Date.now()}`,office:payload.office||'Mayor',stage:'SELECTION',budget,support:clamp(p.polling+(p.grassrootsSupport-25)*.4),momentum:50,volunteers:Math.round(p.grassrootsSupport*20),endorsements:0,scandalRisk:20});
      p.politicalCapital=clamp(p.politicalCapital+3); msg=`Launched a ${payload.office||'Mayor'} campaign with a $${budget.toLocaleString()} war chest.`; break;
    }
    case 'BUILD_CAPITAL': p.politicalCapital=clamp(p.politicalCapital+4); p.grassrootsSupport=clamp(p.grassrootsSupport+2); msg='Built political capital through constituent and institutional engagement.'; break;
    case 'NEGOTIATE': p.institutionalInfluence=clamp(p.institutionalInfluence+4); p.governmentStability=clamp(p.governmentStability+2); msg='Negotiated with political actors and improved institutional alignment.'; break;
    case 'INTRODUCE_BILL': { const b:PoliticalBill={id:`bill_${tick}_${Date.now()}`,title:payload.title||'Economic and Social Reform Bill',sponsor:`${state.character.firstName} ${state.character.lastName}`,status:'COMMITTEE',support:45+Math.round(p.institutionalInfluence*.2),opposition:30,amendments:0,fiscalCost:payload.fiscalCost||0,affectedIndustries:payload.industries||[]}; p.bills.unshift(b); p.politicalCapital=clamp(p.politicalCapital-5); msg=`Introduced ${b.title} and sent it to committee.`; break; }
    case 'AMEND_BILL': { const b=p.bills.find(x=>x.id===payload.billId); if(!b)return {success:false,message:'Bill not found.'}; b.amendments++; b.support=clamp(b.support+3); msg=`Negotiated amendment ${b.amendments} to ${b.title}.`; break; }
    case 'VOTE_BILL': { const b=p.bills.find(x=>x.id===payload.billId); if(!b)return {success:false,message:'Bill not found.'}; const pass=b.support+(p.legislativeApproval*.25)>b.opposition+20; b.status=pass?'PASSED':'FAILED'; if(pass){p.publicTrust=clamp(p.publicTrust+2);p.legislativeApproval=clamp(p.legislativeApproval+2);}else p.governmentStability=clamp(p.governmentStability-3); msg=`${b.title} ${pass?'passed':'failed'} its vote.`; break; }
    case 'CALL_HEARING': p.institutionalInfluence=clamp(p.institutionalInfluence+3); msg='Called a parliamentary/public-interest hearing; affected institutions must provide evidence.'; break;
    case 'APPOINT_MINISTER': p.cabinet.push({ministry:payload.ministry||'Finance',minister:payload.minister||'Qualified NPC Minister',approval:55,performance:60}); p.institutionalInfluence=clamp(p.institutionalInfluence+2); msg=`Appointed ${payload.minister||'a minister'} to ${payload.ministry||'Finance'}.`; break;
    case 'FORM_COALITION': { const seats=payload.seats||55; p.coalitions.unshift({id:`coal_${tick}_${Date.now()}`,partners:payload.partners||['Player Party','Centrist Coalition'],seats,stability:60,concessions:payload.concessions||[]}); p.governmentStability=clamp(p.governmentStability+5); msg='Formed a coalition government through negotiated concessions.'; break; }
    case 'HOLD_RALLY': p.grassrootsSupport=clamp(p.grassrootsSupport+5); p.polling=clamp(p.polling+2); setCooldown(p,action,tick); msg='Held a rally that mobilized supporters and volunteers.'; break;
    case 'PRESS_CONFERENCE': p.mediaInfluence=clamp(p.mediaInfluence+4); p.publicTrust=clamp(p.publicTrust+1); setCooldown(p,action,tick); msg='Held a press conference and shaped the political narrative.'; break;
    case 'MEET_DONORS': p.donorSupport=clamp(p.donorSupport+5); setCooldown(p,action,tick); msg='Met prospective political donors and secured conditional campaign support.'; break;
    case 'POLLING': p.polling=clamp(p.polling+(p.mediaInfluence+p.grassrootsSupport)/80-1); setCooldown(p,action,tick); msg=`Commissioned a polling pulse; estimated support is ${p.polling.toFixed(1)}%.`; break;
    case 'CAMPAIGN_DEBATE': p.mediaInfluence=clamp(p.mediaInfluence+3); p.polling=clamp(p.polling+(state.character.attributes.intelligence-50)/15); setCooldown(p,action,tick); msg='Completed a televised debate; voter sentiment shifted according to performance.'; break;
    case 'RELEASE_POLICY': p.publicTrust=clamp(p.publicTrust+2); p.mediaInfluence=clamp(p.mediaInfluence+2); msg='Released a detailed policy platform to voters and stakeholders.'; break;
    case 'RESPOND_SCANDAL': { const s=p.scandals.find(x=>x.id===payload.scandalId); if(!s)return {success:false,message:'Scandal not found.'}; s.exposure=clamp(s.exposure-15); s.status='INVESTIGATING'; p.publicTrust=clamp(p.publicTrust-1); msg=`Responded publicly to ${s.title} and initiated a fact-based defence.`; break; }
    case 'CHALLENGE_LEADER': p.institutionalInfluence=clamp(p.institutionalInfluence+6); p.governmentStability=clamp(p.governmentStability-4); msg='Launched an internal party leadership challenge; factional politics are now active.'; break;
    case 'RESIGN': state.politics.currentOffice.inOffice=false; state.politics.pastOffices.push(state.politics.currentOffice.title); p.institutionalInfluence=clamp(p.institutionalInfluence-5); msg=`Resigned from ${state.politics.currentOffice.title}.`; break;
    case 'DECLARE_INTEREST': p.publicTrust=clamp(p.publicTrust+2); msg='Declared financial and corporate interests for public transparency.'; break;
    case 'RECUSE': p.institutionalInfluence=clamp(p.institutionalInfluence-1); p.publicTrust=clamp(p.publicTrust+3); msg='Recused yourself from a decision involving a potential conflict of interest.'; break;
    case 'DIPLOMATIC_MISSION': p.diplomaticStanding=clamp(p.diplomaticStanding+4); msg='Completed a diplomatic mission that strengthened international relationships.'; break;
    case 'NEGOTIATE_TREATY': p.diplomaticStanding=clamp(p.diplomaticStanding+5); msg='Negotiated a treaty framework with a foreign government.'; break;
  }
  p.history.unshift({tick,action,summary:msg,impact:`Political capital ${Math.round(p.politicalCapital)}, public trust ${Math.round(p.publicTrust)}, polling ${Math.round(p.polling)}%`}); p.history=p.history.slice(0,100);
  recordWorldPlayerAction(state,`POLITICAL_${action}`,msg,['politics','government','economy','npc','social','companies'],Math.min(95,50+Math.round(p.institutionalInfluence/4)));
  return {success:true,message:msg};
}

export function advanceAdvancedPolitics(state:GameState, country:any, events:any[], news:any[]){
  const p=ensure(state);
  // Politics 4.0 is the unified legislature/electoral layer. Legacy and advanced
  // political structures remain authoritative sources and are synchronized by it.
  ensurePolitics4(state); if(p.lastMonthlyTick===state.simulationTick)return;
  p.lastMonthlyTick=state.simulationTick;
  const economy=country?.businessCycle||'Stable';
  const economicDelta=economy==='Boom'?2:economy==='Recession'?-3:economy==='Recovery'?1:0;
  // Populate a living political ecosystem once, then let NPC actors and factions evolve autonomously.
  if (p.factions.length===0) {
    const templates=[['Reform Coalition','Institutional reform and public services'],['Enterprise Caucus','Business growth and fiscal discipline'],['Labour Alliance','Employment, wages and social protection'],['Green Development Bloc','Climate, infrastructure and sustainable cities'],['National Security Group','Defence, sovereignty and public safety']];
    p.factions=templates.map((x,i)=>({id:`faction_${i+1}`,name:x[0],ideologicalFocus:x[1],parliamentarySeatsPercent:12+i*3,donorCapital:35+i*4,leaderId:`actor_${i+1}`,influenceScore:40+i*5,stanceOnPlayer:'Neutral Observer',policyPriorities:[x[1]]} as any));
    p.actors=templates.map((x,i)=>({id:`actor_${i+1}`,name:['Mara Venn','Julian Cross','Nadia Mercer','Tomas Vale','Iris Kade'][i],currentRole:'Senior Legislator',factionId:`faction_${i+1}`,influenceScore:45+i*6,ambitionScore:45+i*7,politicalCapital:40+i*5,reputation:55,stanceOnPlayer:'Neutral',keyAgenda:x[1],scandalVulnerability:20+i*8} as any));
  }
  p.polling=clamp(p.polling+economicDelta+(p.publicTrust-50)/50+(p.mediaInfluence-30)/100);
  p.governmentStability=clamp(p.governmentStability+(p.publicTrust-50)/100+(p.legislativeApproval-50)/100);
  p.oppositionStrength=clamp(100-p.polling+20);
  p.legislativeApproval=clamp(p.legislativeApproval+(p.governmentStability-50)/100);
  p.budget.revenue=Math.max(0,(country?.gdpBillions||0)*10*(1-(country?.unemploymentRate||5)/100));
  p.budget.expenditure=p.budget.revenue*(0.95+(100-p.governmentStability)/400); p.budget.deficit=p.budget.expenditure-p.budget.revenue;
  for(const f of p.parties){f.pollingPercentage=clamp(f.pollingPercentage+(p.polling-50)*0.01+(Math.random()-.5));f.internalStability=clamp(f.internalStability+(Math.random()-.5)*2);f.membership=Math.max(1000,Math.round(f.membership*(1+(f.pollingPercentage-25)/1000)));}
  for(const f of p.factions){f.influenceScore=clamp(f.influenceScore+(Math.random()-.5)*2);f.parliamentarySeatsPercent=clamp(f.parliamentarySeatsPercent+(f.influenceScore-50)/500);}
  for(const a of p.actors){a.politicalCapital=clamp(a.politicalCapital+(a.reputation-50)/100);a.ambitionScore=clamp(a.ambitionScore+(Math.random()-.5)*2);if(a.ambitionScore>80&&a.stanceOnPlayer==='Neutral')a.stanceOnPlayer='Opposed';}
  // Bills advance through institutional stages instead of remaining static.
  for(const b of p.bills){if(b.status==='COMMITTEE'&&b.support>b.opposition+10)b.status='DEBATE';else if(b.status==='DEBATE'&&b.amendments>0)b.status='VOTE';}
  // Campaigns advance slowly and produce polling momentum, endorsements and pressure.
  for(const c of p.campaigns){c.support=clamp(c.support+(p.mediaInfluence+p.grassrootsSupport-50)/80);c.momentum=clamp(c.momentum+(c.support-50)/60);if(c.stage!=='ELECTION'&&state.simulationTick%2===0){const order=['SELECTION','FUNDRAISING','MEDIA','POLLING','DEBATE','ELECTION'];const i=order.indexOf(c.stage);c.stage=order[Math.min(order.length-1,i+1)] as any;}if(c.stage==='ELECTION'){const win=c.support+p.donorSupport*.15+p.grassrootsSupport*.15>55;if(win){state.politics.currentOffice.title=c.office as any;state.politics.currentOffice.inOffice=true;state.politics.currentOffice.termMonthsRemaining=48;state.politics.currentOffice.salaryMonthly=c.office==='President / Prime Minister'?85000:c.office==='Mayor'?12000:24000;p.publicTrust=clamp(p.publicTrust+5);events.push({id:`ev_election_win_${c.id}`,timestampMonth:state.currentMonth,timestampYear:state.currentYear,age:state.character.age,category:'Politics',title:`Election Victory: ${c.office}`,description:`Your campaign converted voter support into an electoral victory. A new governing mandate begins.`,consequences:{reputationChange:4,worldInfluenceChange:6}});}}}
  if(state.politics.currentOffice.inOffice){state.politics.currentOffice.approvalRating=clamp(p.polling);state.politics.currentOffice.politicalCapital=clamp(p.politicalCapital);}
  advancePolitics4(state,events,news);
  if(p.polling<35 && state.politics.currentOffice.inOffice){p.scandals.unshift({id:`scandal_${state.simulationTick}`,title:'Public Confidence Crisis',severity:55,exposure:40,status:'PUBLIC'});events.push({id:`ev_pol_crisis_${state.simulationTick}`,timestampMonth:state.currentMonth,timestampYear:state.currentYear,age:state.character.age,category:'Politics',title:'Government Confidence Crisis',description:'Falling public confidence has triggered opposition pressure and intensified scrutiny.',consequences:{reputationChange:-2,worldInfluenceChange:1}});news.push({id:`news_pol_crisis_${state.simulationTick}`,month:state.currentMonth,year:state.currentYear,headline:'Government faces rising confidence pressure',body:'Polling, economic conditions and institutional confidence are producing a new political challenge.',category:'Politics',importance:'MAJOR',severity:'Warning',impactExplanation:'Political stability has weakened.'});}
}

export function getAdvancedPolitics(state:GameState){return ensure(state);}
