import { GameState } from '../types';

const DB_NAME = 'dominium_local_world';
const STORE = 'saves';
const KEY = 'active_world';
const FALLBACK_KEY = 'dominium_device_world_v1';

function openDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise(resolve => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE); };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => resolve(null);
  });
}

export async function persistWorldToDevice(state: GameState): Promise<void> {
  const payload = JSON.stringify(state);
  try { localStorage.setItem(FALLBACK_KEY, payload); } catch { /* IndexedDB may still succeed */ }
  const db = await openDb();
  if (!db) return;
  await new Promise<void>(resolve => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(payload, KEY);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); resolve(); };
  });
}

export async function loadWorldFromDevice(): Promise<GameState | null> {
  const db = await openDb();
  if (db) {
    const payload = await new Promise<string | null>(resolve => {
      const tx = db.transaction(STORE, 'readonly');
      const request = tx.objectStore(STORE).get(KEY);
      request.onsuccess = () => resolve(typeof request.result === 'string' ? request.result : null);
      request.onerror = () => resolve(null);
      tx.oncomplete = () => db.close();
    });
    if (payload) { try { return JSON.parse(payload) as GameState; } catch {} }
  }
  try { const payload = localStorage.getItem(FALLBACK_KEY); return payload ? JSON.parse(payload) as GameState : null; } catch { return null; }
}

export async function clearDeviceWorld(): Promise<void> {
  try { localStorage.removeItem(FALLBACK_KEY); } catch {}
  const db = await openDb();
  if (!db) return;
  await new Promise<void>(resolve => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(KEY);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); resolve(); };
  });
}
