import { GameState, DailyLifeActivity, DailyLifeActivityDomain, LifeEvent, PersonalDailyLifeSchedulerState } from '../types';
import { ensureLifeSystemState, getLifeAllocationTotals } from './lifeEngine';
import { ensureLifeExpansion } from './lifeExpansionEngine';
import { recordWorldPlayerAction } from './worldGovernorCoordinator';

const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));
const monthKey=(s:GameState)=>`${s.currentYear}-${String(s.currentMonth).padStart(2,'0')}`;
const daysInMonth=(year:number,month:number)=>new Date(year,month,0).getDate();
function hash(seed:string){let h=2166136261;for(let i=0;i<seed.length;i++){h^=seed.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0)/4294967296;}
function ensure(s:GameState):PersonalDailyLifeSchedulerState{
  const life=ensureLifeSystemState(s) as any;
  if(!life.dailyLifeScheduler) life.dailyLifeScheduler={version:1,monthKey:monthKey(s),daysInMonth:daysInMonth(s.currentYear,s.currentMonth),currentDay:0,activities:[],interruptions:[],appointments:[],npcAvailability:{},travelWindows:[],aggregatedLowValueCount:0,surfacedEventIds:[],completedDayCount:0,lastGeneratedTick:-1};
  return life.dailyLifeScheduler;
}
const DOMAIN_MAP:Array<{key:keyof ReturnType<typeof getLifeAllocationTotals>;domain:DailyLifeActivityDomain;title:string}>=[
 {key:'career',domain:'CAREER',title:'Work / Career'}, {key:'education',domain:'EDUCATION',title:'Study / Education'}, {key:'family',domain:'FAMILY',title:'Family time'}, {key:'partner',domain:'PARTNER',title:'Partner / Romance'}, {key:'friends',domain:'FRIENDS',title:'Friends / Social'}, {key:'wellness',domain:'WELLNESS',title:'Fitness / Recovery'}, {key:'hobbies',domain:'HOBBY',title:'Hobby / Recreation'}, {key:'socialMedia',domain:'SOCIAL_MEDIA',title:'Social media'}, {key:'entrepreneurship',domain:'ENTREPRENEURSHIP',title:'Business / Enterprise'}
];
function makeActivity(id:string,day:number,start:number,duration:number,domain:DailyLifeActivityDomain,title:string,importance:number,source:DailyLifeActivity['source'],npcIds?:string[]):DailyLifeActivity{return {id,day,startHour:start,durationHours:duration,domain,title,importance,status:'SCHEDULED',source,npcIds};}
function generateMonth(s:GameState,l:PersonalDailyLifeSchedulerState){
  const alloc=getLifeAllocationTotals(ensureLifeSystemState(s).timeAllocation); const d=l.daysInMonth; l.activities=[]; l.appointments=[]; l.interruptions=[]; l.travelWindows=[]; l.npcAvailability={}; l.aggregatedLowValueCount=0; l.surfacedEventIds=[]; l.completedDayCount=0; l.currentDay=0;
  const startByDay:Record<number,number>={1:8,2:9,3:10,4:8,5:9,6:10,7:8};
  for(const item of DOMAIN_MAP){
    const hours=Math.round(Number(alloc[item.key]||0)); if(hours<=0) continue;
    const count=Math.max(1,Math.round(hours/Math.max(1,Math.min(8,hours/d))));
    const per=Math.max(1,Math.min(6,hours/Math.max(1,count)));
    for(let i=0;i<count;i++){
      const day=1+((i*7+Math.floor(hash(`${s.character.id}:${item.key}:${i}`)*7))%d);
      const weekend=new Date(s.currentYear,s.currentMonth-1,day).getDay()===0||new Date(s.currentYear,s.currentMonth-1,day).getDay()===6;
      if(item.domain==='CAREER' && weekend) continue;
      const start=startByDay[(i%7)+1] + Math.floor(hash(`${item.domain}:hour:${i}`)*3);
      l.activities.push(makeActivity(`day_${s.simulationTick}_${item.domain}_${i}`,day,start,Math.round(per*10)/10,item.domain,item.title, item.domain==='CAREER'||item.domain==='PARTNER'?50:35,'ROUTINE'));
    }
  }
  // Human routine: every day gets sleep/commute/household buffers without consuming controllable allocations.
  for(let day=1;day<=d;day++){
    l.activities.push(makeActivity(`routine_morning_${s.simulationTick}_${day}`,day,7,1,'ROUTINE','Morning routine & planning',20,'ROUTINE'));
    l.activities.push(makeActivity(`routine_evening_${s.simulationTick}_${day}`,day,20,1,'ROUTINE','Evening routine & reset',20,'ROUTINE'));
  }
  const importantNpcIds=(s.relationships||[]).filter(r=>r.alive).slice(0,8).map(r=>r.id);
  importantNpcIds.forEach((id,i)=>{const slots:number[]=[];for(let day=1;day<=d;day++) if((day+i)%3!==0) slots.push(day);l.npcAvailability[id]=slots;});
  // Existing travel-capable possessions create a few realistic windows; the player chooses whether to use them.
  const inventory=(ensureLifeSystemState(s).marketplaceInventory||[]).filter((x:any)=>x.purchased);
  if(inventory.some((x:any)=>/aircraft|plane|jet/i.test(x.category||x.type||x.name||''))){l.travelWindows.push({day:7,startHour:9,endHour:18,destination:'Regional business or leisure destination'});}
  if(inventory.some((x:any)=>/boat|yacht|ship/i.test(x.category||x.type||x.name||''))){l.travelWindows.push({day:14,startHour:9,endHour:17,destination:'Coastal leisure destination'});}
  if(inventory.some((x:any)=>/car|vehicle/i.test(x.category||x.type||x.name||''))){l.travelWindows.push({day:21,startHour:8,endHour:20,destination:'Nearby city or weekend destination'});}
  l.lastGeneratedTick=s.simulationTick;
}
function addMeaningfulEvent(s:GameState,out:LifeEvent[],l:PersonalDailyLifeSchedulerState,title:string,summary:string,importance:number,domain:string){
  const id=`daily_${s.simulationTick}_${l.surfacedEventIds.length}`; if(l.surfacedEventIds.includes(id)) return;
  l.surfacedEventIds.push(id); out.push({id,timestampMonth:s.currentMonth,timestampYear:s.currentYear,age:s.character.age,category:'Life',title,description:summary,priority:importance,severity:importance>=85?'High':importance>=65?'Major':'Moderate',consequences:{details:[`Daily-life domain: ${domain}.`,`Surfaced by Governor importance scoring.`]}} as any);
}
function processDailyInterruptions(s:GameState,out:LifeEvent[],l:PersonalDailyLifeSchedulerState){
  const day=l.currentDay; const seed=hash(`${s.character.id}:${s.simulationTick}:${day}:interrupt`);
  // Low-value daily activity is deliberately aggregated; only high-signal interruptions surface.
  if(seed<0.12){
    const options=[
      ['NPC','A colleague or family member asks for an unscheduled conversation.'],
      ['CAREER','A workplace request conflicts with your planned day.'],
      ['HOUSEHOLD','A household task needs attention before it becomes expensive.'],
      ['TRAVEL','A time-sensitive invitation creates a possible travel window.'],
      ['FINANCE','A personal financial matter needs same-week attention.']
    ] as const;
    const [domain,summary]=options[Math.floor(seed*options.length*8)%options.length];
    const importance=domain==='CAREER'||domain==='FINANCE'?68:58;
    const id=`interrupt_${s.simulationTick}_${day}`;
    l.interruptions.push({id,day,title:`${domain} interruption`,summary,importance,resolved:false});
    if(importance>=65) addMeaningfulEvent(s,out,l,`Day ${day}: ${domain.toLowerCase()} interruption`,summary,importance,domain);
    else l.aggregatedLowValueCount++;
  } else l.aggregatedLowValueCount++;
}
export function initializeDailyLifeSchedule(s:GameState){const l=ensure(s);const k=monthKey(s);if(l.monthKey!==k||l.lastGeneratedTick<0){l.monthKey=k;l.daysInMonth=daysInMonth(s.currentYear,s.currentMonth);generateMonth(s,l);}return l;}
export function advanceDailyLifeScheduler(s:GameState,out:LifeEvent[]=[]){
  const l=initializeDailyLifeSchedule(s); const target=Math.min(l.daysInMonth,l.currentDay+ l.daysInMonth); // one complete simulated month per monthly tick
  while(l.currentDay<target){
    l.currentDay++; l.completedDayCount++;
    processDailyInterruptions(s,out,l);
    // Execute planned routines as background state, with only important deviations surfaced.
    const todays=l.activities.filter(a=>a.day===l.currentDay&&a.status==='SCHEDULED');
    for(const a of todays){a.status='COMPLETED'; if(a.importance<55) l.aggregatedLowValueCount++;}
    const travel=l.travelWindows.find(t=>t.day===l.currentDay);
    if(travel && todays.some(a=>a.domain==='HOBBY'||a.domain==='PARTNER'||a.domain==='FRIENDS')) addMeaningfulEvent(s,out,l,'Travel window available',`A ${travel.destination.toLowerCase()} window is available today. Existing possessions and your schedule make the trip feasible.`,62,'TRAVEL');
  }
  // Apply small aggregate routine effects once per monthly simulation, preventing 30x notification spam.
  const totals=getLifeAllocationTotals(ensureLifeSystemState(s).timeAllocation); const a=s.character.attributes;
  if(totals.wellness>=60) a.stress=clamp(a.stress-2);
  if(totals.family+totals.partner>=120) a.happiness=clamp(a.happiness+2);
  if(totals.career>=180 && s.currentJob) s.currentJob.performance=clamp(s.currentJob.performance+1);
  if(totals.education>=80 && ensureLifeSystemState(s).currentDegreeStatus) ensureLifeSystemState(s).currentDegreeStatus!.gpa=clamp(ensureLifeSystemState(s).currentDegreeStatus!.gpa+0.03,0,4);
  recordWorldPlayerAction(s,'DAILY_LIFE_SCHEDULE','Monthly daily-life schedule completed and aggregated by Governor.', ['life','npc','career','relationships','health','travel','finance','world'],70);
  return out;
}
export function getDailyLifeSummary(s:GameState){const l=initializeDailyLifeSchedule(s);return {day:l.currentDay,days:l.daysInMonth,scheduled:l.activities.length,completed:l.activities.filter(a=>a.status==='COMPLETED').length,interruptions:l.interruptions.length,importantInterruptions:l.interruptions.filter(i=>i.importance>=65&&!i.resolved).length,aggregated:l.aggregatedLowValueCount,travelWindows:l.travelWindows.length,appointments:l.appointments.length};}
