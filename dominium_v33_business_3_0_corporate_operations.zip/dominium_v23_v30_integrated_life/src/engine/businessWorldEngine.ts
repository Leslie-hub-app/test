import { GameState, Company, LifeEvent } from '../types';
import { recordFinancialTransaction } from './financialLedgerEngine';
import { recordWorldPlayerAction } from './worldGovernorCoordinator';

type Employee = { id:string; name:string; role:string; salaryMonthly:number; skill:number; morale:number; performance:number; ambition:number; loyalty:number; active:boolean; };
type BusinessWorldState = {
  version:number;
  lastProcessedTick:number;
  employees: Record<string, Employee[]>;
  customerBase: Record<string, number>;
  supplierHealth: Record<string, number>;
  competitorPressure: Record<string, number>;
  departmentHealth: Record<string, Record<string, number>>;
  opportunities: {id:string; companyId:string; type:string; title:string; value:number; expiresTick:number; status:'OPEN'|'ACCEPTED'|'DECLINED'|'EXPIRED'}[];
  contracts: {id:string; companyId:string; counterparty:string; value:number; monthsRemaining:number; margin:number; status:'ACTIVE'|'COMPLETED'|'DEFAULTED'}[];
  loans: {id:string; companyId:string; principal:number; rate:number; monthsRemaining:number; monthlyPayment:number; status:'ACTIVE'|'DEFAULTED'|'PAID'}[];
  history: {tick:number; companyId:string; type:string; summary:string}[];
};

const clamp=(n:number,a=0,b=100)=>Math.max(a,Math.min(b,n));
const ensure=(s:GameState):BusinessWorldState=>{
  const root:any=s as any;
  if(!root.businessWorld) root.businessWorld={version:1,lastProcessedTick:-1,employees:{},customerBase:{},supplierHealth:{},competitorPressure:{},departmentHealth:{},opportunities:[],contracts:[],loans:[],history:[]};
  const b=root.businessWorld as BusinessWorldState;
  for(const c of s.companies){
    if(!b.customerBase[c.id]) b.customerBase[c.id]=c.customerBase||Math.max(100,Math.round((c.monthlyRevenue||0)/Math.max(1,c.unitPrice||1)));
    if(!b.supplierHealth[c.id]) b.supplierHealth[c.id]=75;
    if(!b.competitorPressure[c.id]) b.competitorPressure[c.id]=clamp(35+(c.marketShare||0)*.8);
    if(!b.departmentHealth[c.id]) b.departmentHealth[c.id]={OPERATIONS:70,SALES:70,MARKETING:70,FINANCE:75,HR:70,RD:65,LEGAL:75};
    if(!b.employees[c.id]) b.employees[c.id]=[];
  }
  return b;
};

export function ensureBusinessWorld(s:GameState){ return ensure(s); }

function seedEmployees(c:Company,b:BusinessWorldState){
  if(b.employees[c.id].length) return;
  const count=Math.max(1,Math.min(60,Math.round(c.employeesCount||6)));
  const roles=['Operations','Sales','Finance','Marketing','Technology','HR','Customer Service'];
  for(let i=0;i<count;i++) b.employees[c.id].push({id:`emp_${c.id}_${i}`,name:`${roles[i%roles.length]} Specialist ${i+1}`,role:roles[i%roles.length],salaryMonthly:Math.max(1800,Math.round((c.averageEmployeeSalary||4500)*(0.8+(i%5)*.07))),skill:55+(i*7)%35,morale:c.employeeMorale||75,performance:c.employeeProductivity||75,ambition:45+(i*11)%45,loyalty:50+(i*13)%45,active:true});
}

function maybeOpportunity(s:GameState,c:Company,b:BusinessWorldState){
  const open=b.opportunities.filter(x=>x.companyId===c.id&&x.status==='OPEN');
  if(open.length>=2) return;
  const seed=(s.simulationTick*17+c.id.length*31)%100;
  if(seed>28) return;
  const types=['NEW_CONTRACT','EXPANSION','PARTNERSHIP','TALENT','SUPPLIER_DEAL'];
  const type=types[seed%types.length];
  const value=Math.max(5000,Math.round((c.monthlyRevenue||10000)*(0.25+(seed%4)*.12)));
  b.opportunities.push({id:`bizopp_${s.simulationTick}_${c.id}_${seed}`,companyId:c.id,type,title:type==='NEW_CONTRACT'?'Potential customer contract':type==='EXPANSION'?'Expansion opportunity':type==='PARTNERSHIP'?'Strategic partnership proposal':type==='TALENT'?'Key executive recruitment opportunity':'Supplier renegotiation opportunity',value,expiresTick:s.simulationTick+2,status:'OPEN'});
}

export function simulateMonthlyBusinessWorld(s:GameState, out:LifeEvent[]=[]){
  const b=ensure(s); if(b.lastProcessedTick===s.simulationTick)return out; b.lastProcessedTick=s.simulationTick;
  for(const c of s.companies){
    seedEmployees(c,b);
    const dept=b.departmentHealth[c.id];
    const employees=b.employees[c.id];
    const avgPerf=employees.length?employees.reduce((a,e)=>a+e.performance,0)/employees.length:(c.employeeProductivity||70);
    const avgMorale=employees.length?employees.reduce((a,e)=>a+e.morale,0)/employees.length:(c.employeeMorale||70);
    const turnover=employees.filter(e=>e.active && (e.morale<35 || e.loyalty<30)).length;
    const supplier=b.supplierHealth[c.id];
    const competition=b.competitorPressure[c.id];
    const demand=clamp(55+(c.brandReputation||50)*.25+(c.productQuality||50)*.2-competition*.22+(c.marketingBudgetMonthly>0?8:0));
    const ops=(s as any).businessOperations?.companies?.[c.id];
    const revenueBase=Math.max(0,c.monthlyRevenue||0);
    const revenue=ops?.lastProcessedTick===s.simulationTick ? Math.max(0,Math.round(ops.operationalRevenue*(0.92+demand/1000)*(0.94+avgPerf/1500))) : Math.max(0,Math.round(revenueBase*(0.88+demand/500)*(0.9+avgPerf/1000)));
    const disruption=supplier<40?0.12:0;
    if(ops?.lastProcessedTick!==s.simulationTick){ c.monthlyRevenue=revenue; c.monthlyExpenses=Math.round((c.monthlyExpenses||0)*(0.97+turnover*.01)+revenue*disruption); c.monthlyNetProfit=c.monthlyRevenue-c.monthlyExpenses; } else { c.monthlyRevenue=revenue; c.monthlyExpenses=Math.round((ops.operationalExpenses||c.monthlyExpenses||0)+revenue*disruption); c.monthlyNetProfit=c.monthlyRevenue-c.monthlyExpenses; }
    c.cashReserve=(c.cashReserve??c.cash??0)+c.monthlyNetProfit;
    c.cash=c.cashReserve;
    c.customerBase=Math.max(0,Math.round((b.customerBase[c.id]||100)*(0.98+demand/500)));
    b.customerBase[c.id]=c.customerBase;
    c.employeeMorale=clamp(avgMorale+(c.monthlyNetProfit>0?1:-2));
    c.employeeProductivity=clamp(avgPerf+(c.monthlyNetProfit>0?1:-2));
    c.marketShare=clamp((c.marketShare||1)+(demand>60?.15:-.12));
    c.brandReputation=clamp((c.brandReputation||50)+(c.monthlyNetProfit>0?0.4:-0.7));
    c.valuation=Math.max(0,Math.round((c.monthlyRevenue*12)*Math.max(.5,1.5+(c.brandReputation-50)/100)));
    dept.SALES=clamp(dept.SALES+(demand-50)*.05); dept.OPERATIONS=clamp(dept.OPERATIONS+(supplier-70)*.03); dept.HR=clamp(dept.HR+(avgMorale-70)*.04); dept.FINANCE=clamp(dept.FINANCE+(c.monthlyNetProfit>=0?1:-3));
    b.supplierHealth[c.id]=clamp(supplier+((s.currentMonth%5===0)?-8:2));
    b.competitorPressure[c.id]=clamp(competition+(s.currentMonth%7===0?4:-1));
    for(const e of employees){ if(!e.active)continue; e.performance=clamp(e.performance+(c.monthlyNetProfit>0?1:-2)); e.morale=clamp(e.morale+(c.monthlyNetProfit>0?1:-1)); e.loyalty=clamp(e.loyalty+(e.morale>70?1:-2)); }
    maybeOpportunity(s,c,b);
    const contracts=b.contracts.filter(x=>x.companyId===c.id&&x.status==='ACTIVE');
    for(const k of contracts){ k.monthsRemaining--; if(k.monthsRemaining<=0){k.status='COMPLETED'; c.monthlyRevenue+=Math.round(k.value/3);}}
    if(c.monthlyNetProfit<0 && c.cashReserve<Math.max(10000,c.monthlyExpenses*1.5)){
      const id=`biz_crisis_${s.simulationTick}_${c.id}`;
      if(!out.some(e=>e.id===id)) out.push({id,timestampMonth:s.currentMonth,timestampYear:s.currentYear,age:s.character.age,category:'Business',title:`Liquidity pressure at ${c.name}`,description:`${c.name} is approaching a working-capital problem. Management should review costs, financing, pricing or growth plans.`,priority:72,severity:'Major',consequences:{details:['Business cash reserve is below a prudent operating buffer.','Potential consequences include financing pressure, layoffs or restructuring.']}} as any);
    }
    if(turnover>Math.max(1,Math.round(employees.length*.12))){out.push({id:`biz_turnover_${s.simulationTick}_${c.id}`,timestampMonth:s.currentMonth,timestampYear:s.currentYear,age:s.character.age,category:'Business',title:`Employee retention warning at ${c.name}`,description:`Employee morale and loyalty are producing elevated turnover pressure.`,priority:62,severity:'Moderate',consequences:{details:['Workforce continuity may deteriorate if management does not respond.']}} as any);}
  }
  for(const o of b.opportunities){if(o.status==='OPEN'&&o.expiresTick<=s.simulationTick)o.status='EXPIRED';}
  if(out.length) recordWorldPlayerAction(s,'BUSINESS_WORLD_MONTH',`Business ecosystem processed ${s.companies.length} company(ies) with autonomous workforce, demand, competition, supplier and opportunity dynamics.`,['business','companies','employment','finance','real-estate','banking','social-media','politics','world-governor'],70);
  return out;
}

export function acceptBusinessOpportunity(s:GameState, opportunityId:string){
  const b=ensure(s); const o=b.opportunities.find(x=>x.id===opportunityId&&x.status==='OPEN'); if(!o)return false; const c=s.companies.find(x=>x.id===o.companyId); if(!c)return false;
  o.status='ACCEPTED'; const contract={id:`contract_${Date.now()}`,companyId:c.id,counterparty:'Simulated Counterparty',value:o.value,monthsRemaining:3,margin:.18,status:'ACTIVE' as const};b.contracts.push(contract);recordWorldPlayerAction(s,'BUSINESS_ACCEPT_OPPORTUNITY',`Accepted ${o.title} for ${c.name}.`,['business','companies','world'],65);return true;
}
export function declineBusinessOpportunity(s:GameState, opportunityId:string){const b=ensure(s);const o=b.opportunities.find(x=>x.id===opportunityId&&x.status==='OPEN');if(!o)return false;o.status='DECLINED';recordWorldPlayerAction(s,'BUSINESS_DECLINE_OPPORTUNITY',`Declined ${o.title}.`,['business','companies','world'],45);return true;}
export function hireBusinessEmployee(s:GameState, companyId:string, name:string, role:string, salary:number){const b=ensure(s);const c=s.companies.find(x=>x.id===companyId);if(!c)return false;const e={id:`emp_${Date.now()}`,name,role,salaryMonthly:salary,skill:70,morale:75,performance:70,ambition:65,loyalty:70,active:true};b.employees[companyId].push(e);c.employeesCount=(c.employeesCount||0)+1;recordFinancialTransaction(s,{type:'SALARY_PAYMENT',category:'EXPENSE',amount:salary,description:`Hired ${name} as ${role} at ${c.name}`,destinationAccount:'Corporate Payroll'} as any);return true;}
export function fireBusinessEmployee(s:GameState,companyId:string,employeeId:string){const b=ensure(s);const c=s.companies.find(x=>x.id===companyId);const e=b.employees[companyId]?.find(x=>x.id===employeeId);if(!c||!e)return false;e.active=false;c.employeesCount=Math.max(0,(c.employeesCount||1)-1);e.morale=0;recordWorldPlayerAction(s,'BUSINESS_TERMINATION',`Terminated ${e.name} at ${c.name}.`,['business','employment','life','world'],55);return true;}
