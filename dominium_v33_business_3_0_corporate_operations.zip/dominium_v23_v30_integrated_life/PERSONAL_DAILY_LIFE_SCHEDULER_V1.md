# DOMINIUM Personal Daily-Life Scheduler V1

The monthly Life Operating System allocation is now converted into a deterministic daily schedule inside each simulated month. The scheduler creates routine activities, workday/weekend constraints, NPC availability windows, travel windows from owned transport assets, and meaningful interruptions.

## Governor behavior
Low-value routine activity is completed and counted without generating inbox items. Only higher-importance interruptions are surfaced as Life events. A monthly aggregate signal is written to the World Governor so the broader engines receive one coordinated life signal instead of 30 days of notification noise.

## Runtime
`advanceDailyLifeScheduler` runs as part of `advanceOneMonth` after the autonomous Living Life engine. The scheduler is persisted in `lifeSystem.dailyLifeScheduler`, resets for the next calendar month, and is therefore compatible with offline saves and worker-based long simulations.
