<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/85db83de-adfc-4b9d-b735-486dc26db4a8

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Corporate Capital Markets v3
The corporate engine now includes institutional shareholder politics, annual general meetings, CEO compensation/options, activist campaigns, debt issuance, IPOs/secondary offerings, financial distress and restructuring, cross-border M&A, antitrust cases, government procurement, company-funded government relations, and persistent corporate history.
